-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2024 at 09:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ash`
--
CREATE DATABASE IF NOT EXISTS `ash` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ash`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `status`) VALUES
(1, 'admin', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', 'A'),
(3, 'Admin', '3b612c75a7b5048a435fb6ec81e52ff92d6d795a8b5a9c17070f6a63c97a53b2', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `ash`
--

CREATE TABLE `ash` (
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ash`
--

INSERT INTO `ash` (`name`, `password`, `email`, `status`) VALUES
('harsh', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'harshmhamunkar71@gmail.com', 'A'),
('harsh', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'harshmhamunkar71@gmail.com', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `basic_details`
--

CREATE TABLE `basic_details` (
  `id` int(100) NOT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `pincode` varchar(100) DEFAULT NULL,
  `number` int(20) DEFAULT NULL,
  `dob` varchar(100) DEFAULT NULL,
  `age` varchar(20) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `basic_details`
--

INSERT INTO `basic_details` (`id`, `fname`, `lname`, `address`, `email`, `pincode`, `number`, `dob`, `age`, `gender`, `status`) VALUES
(1, 'Omkar', 'Pawar', '4/5 rajni niwas bandrekarwadi jogeshwari east', 'omkarpawar982@gmail.com', '400060', 2147483647, '2022-03-10', 'below 5 years', 'male', 'A'),
(2, 'omkzr', 'Pawar', '4/5 rajni niwas bandrekarwadi jogeshwari east', 'hamzaindorwala3@mgmail.com', '400060', 12345678, '2022-03-17', '11-15 years', 'male', 'A'),
(3, 'Omkar', 'Pawar', '4/5 rajni niwas bandrekarwadi jogeshwari east', 'omkarpawar982@gmail.com', '400060', 987654321, '2022-03-17', 'below 5 years', 'male', 'A'),
(4, 'Omkar', 'Pawar', '4/5 rajni niwas bandrekarwadi jogeshwari east', 'gauri27salgaonkar@gmail.com', '400060', 987654311, '2022-04-02', '11-15 years', 'male', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `book_ride`
--

CREATE TABLE `book_ride` (
  `id` int(100) NOT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `select_cycle` varchar(100) DEFAULT NULL,
  `select_centre` varchar(100) DEFAULT NULL,
  `date_slot` varchar(100) DEFAULT NULL,
  `time_slot` varchar(100) DEFAULT NULL,
  `booking_status` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_ride`
--

INSERT INTO `book_ride` (`id`, `user_id`, `select_cycle`, `select_centre`, `date_slot`, `time_slot`, `booking_status`, `status`) VALUES
(28, '3', NULL, NULL, '', '', 'P', 'A'),
(29, '4', 'HERCULES', 'Borivali', '2022-12-06', '12pm - 1pm', 'P', 'A'),
(37, '10', 'HERCULES', 'Borivali', '2023-03-24', '12pm - 1pm', 'P', 'A'),
(38, '10', 'HERCULES', 'Borivali', '', '8am - 9am', 'P', 'A'),
(39, '10', 'HERCULES', 'Borivali', '', '8am - 9am', 'P', 'A'),
(40, '10', 'HERCULES', 'Borivali', '2023-03-22', '9am - 10am', 'P', 'A'),
(42, '12', 'HERCULES', 'Borivali', '2023-03-24', '1pm - 2pm', 'P', 'A'),
(49, '10', 'HERCULES', 'Jogeshwari', '', '1pm - 2pm', 'P', 'A'),
(63, NULL, 'apache', 'powai', '2024-03-19', '8am - 9am', 'P', 'A'),
(64, NULL, 'firefox', 'powai', '2024-03-05', '8am - 9am', 'P', 'A'),
(65, NULL, 'firefox', 'andheri', '2024-03-04', '8am - 9am', 'P', 'A'),
(66, NULL, 'firefox', 'powai', '2024-03-07', '8am - 9am', 'P', 'A'),
(67, NULL, 'firefox', 'powai', '', '8am - 9am', 'P', 'A'),
(68, NULL, 'firefox', 'powai', '2024-03-06', '8am - 9am', 'P', 'A'),
(69, NULL, 'firefox', 'powai', '2024-03-05', '8am - 9am', 'P', 'A'),
(70, NULL, 'firefox', 'powai', '2024-03-06', '8am - 9am', 'P', 'A'),
(71, NULL, 'HUSTLE', 'powai', '2024-03-06', '8am - 9am', 'P', 'A'),
(72, NULL, 'HUSTLE', 'powai', '2024-03-06', '8am - 9am', 'P', 'A'),
(73, NULL, 'STRYDER', 'powai', '2024-03-06', '8am - 9am', 'P', 'A'),
(74, NULL, 'STRYDER', 'andheri', '2024-03-06', '8am - 9am', 'P', 'A'),
(75, NULL, 'STRYDER', 'powai', '2024-03-06', '8am - 9am', 'P', 'A'),
(76, NULL, 'STRYDER', 'powai', '2024-03-06', '8am - 9am', 'P', 'A'),
(77, NULL, 'STRYDER', 'powai', '2024-03-06', '8am - 9am', 'P', 'A'),
(78, NULL, 'STRYDER', 'powai', '2024-03-06', '8am - 9am', 'P', 'A'),
(79, NULL, 'STRYDER', 'andheri', '2024-03-06', '8am - 9am', 'P', 'A'),
(80, NULL, 'BTWIN NG', 'powai', '2024-03-07', '8am - 9am', 'P', 'A'),
(81, NULL, 'BTWIN NG', 'powai', '2024-03-07', '8am - 9am', 'P', 'A'),
(82, NULL, 'DECATHLON', 'powai', '2024-03-07', '8am - 9am', 'P', 'A'),
(83, NULL, 'DECATHLON', 'powai', '2024-03-07', '8am - 9am', 'P', 'A'),
(84, NULL, 'DECATHLON', 'powai', '2024-03-07', '8am - 9am', 'P', 'A'),
(85, NULL, 'STRYDER', 'powai', '2024-03-09', '8am - 9am', 'P', 'A'),
(86, NULL, 'STRYDER', 'powai', '2024-03-09', '8am - 9am', 'P', 'A'),
(87, NULL, 'STRYDER', 'powai', '2024-03-09', '8am - 9am', 'P', 'A'),
(88, NULL, 'STRYDER', 'andheri', '2024-03-09', '8am - 9am', 'P', 'A'),
(89, NULL, 'STRYDER', 'andheri', '2024-03-09', '8am - 9am', 'P', 'A'),
(90, NULL, 'STRYDER', 'powai', '2024-03-09', '8am - 9am', 'P', 'A'),
(91, NULL, 'STRYDER', 'andheri', '2024-03-09', '8am - 9am', 'P', 'A'),
(92, NULL, 'STRYDER', 'powai', '2024-03-10', '8am - 9am', 'P', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `centre_details`
--

CREATE TABLE `centre_details` (
  `id` int(100) NOT NULL,
  `centre_name` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `pincode` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `number` varchar(100) DEFAULT NULL,
  `time` varchar(100) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `centre_details`
--

INSERT INTO `centre_details` (`id`, `centre_name`, `address`, `pincode`, `email`, `number`, `time`, `image`, `status`) VALUES
(5, 'powai', '3 F trimurti sangarsha nagar chandivali farm road andheri E 400072', '400072', 'admin@example.com', '3654488965', '', 'centre_img/Screenshot (310).-1679895380.png', 'A'),
(6, 'andheri', 'nnp colony', '400065', 'harshmhamunkar71@gmail.com', '8685254154', '3am to 9am', 'centre_img/16.-1709272732.jpg', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `cycle_details`
--

CREATE TABLE `cycle_details` (
  `id` int(100) NOT NULL,
  `cycle_name` varchar(100) DEFAULT NULL,
  `cycle_type` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `cycle_price` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cycle_details`
--

INSERT INTO `cycle_details` (`id`, `cycle_name`, `cycle_type`, `description`, `image`, `status`, `cycle_price`) VALUES
(12, 'STRYDER', 'Non-Gear', 'A non gear cycle which has good breaking mechanism and suspension for comfortable ride.', '../cycle_img/non_gear3.-1709650243.jpg', 'A', 120.00),
(13, 'HUSTLE', 'Gear', 'A gear cycle which has good breaking mechanism and suspension for comfortable ride.', '../cycle_img/HUSTLE.-1709652097.jpg', 'A', 200.00),
(14, 'DECATHLON', 'Gear', 'A gear cycle which has good breaking mechanism and suspension for comfortable ride.', '../cycle_img/DECATHLON.-1709697661.jpg', 'A', 200.00),
(15, 'BTWIN NG', 'Non-Gear', 'A non gear cycle which has good breaking mechanism and suspension for comfortable ride', '../cycle_img/BTWIN NG.-1709697829.jpg', 'A', 120.00);

-- --------------------------------------------------------

--
-- Table structure for table `elec_admin`
--

CREATE TABLE `elec_admin` (
  `id` int(100) NOT NULL,
  `username` varchar(150) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `added_on` varchar(150) DEFAULT NULL,
  `added_by` varchar(150) DEFAULT NULL,
  `modified_on` varchar(150) DEFAULT NULL,
  `modified_by` varchar(150) DEFAULT NULL,
  `deleted_on` varchar(150) DEFAULT NULL,
  `deleted_by` varchar(150) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `elec_admin`
--

INSERT INTO `elec_admin` (`id`, `username`, `password`, `status`, `added_on`, `added_by`, `modified_on`, `modified_by`, `deleted_on`, `deleted_by`, `timestamp`) VALUES
(2, 'admin', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2022-02-24 15:00:28');

-- --------------------------------------------------------

--
-- Table structure for table `elec_blog`
--

CREATE TABLE `elec_blog` (
  `id` int(100) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `description` text NOT NULL,
  `image` varchar(150) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `added_on` varchar(150) DEFAULT NULL,
  `added_by` varchar(150) DEFAULT NULL,
  `modified_on` varchar(150) DEFAULT NULL,
  `modified_by` varchar(150) DEFAULT NULL,
  `deleted_on` varchar(150) DEFAULT NULL,
  `deleted_by` varchar(150) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `elec_bookings`
--

CREATE TABLE `elec_bookings` (
  `id` int(11) NOT NULL,
  `booking_id` varchar(150) DEFAULT NULL,
  `trans_id` varchar(150) DEFAULT NULL,
  `pay_id` varchar(150) DEFAULT NULL,
  `vehicle_id` varchar(150) DEFAULT NULL,
  `user_id` varchar(255) NOT NULL,
  `amount` varchar(150) DEFAULT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `booking_date` varchar(100) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `added_on` varchar(150) DEFAULT NULL,
  `added_by` varchar(150) DEFAULT NULL,
  `modified_on` varchar(150) DEFAULT NULL,
  `modified_by` varchar(150) DEFAULT NULL,
  `deleted_on` varchar(150) DEFAULT NULL,
  `deleted_by` varchar(150) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `elec_bookings`
--

INSERT INTO `elec_bookings` (`id`, `booking_id`, `trans_id`, `pay_id`, `vehicle_id`, `user_id`, `amount`, `duration`, `booking_date`, `status`, `added_on`, `added_by`, `modified_on`, `modified_by`, `deleted_on`, `deleted_by`, `timestamp`) VALUES
(1, '00000001', NULL, '0', '1', '1', '200', 'l20', '2022-04-29', 'A', 'admin', '18-04-2022 12:32:18', NULL, NULL, NULL, NULL, '2022-04-17 19:02:35'),
(2, '00000002', NULL, '0', '2', '1', '250', '60', '2022-04-17', 'A', 'admin', '18-04-2022 01:01:13', NULL, NULL, NULL, NULL, '2022-04-17 19:31:43'),
(3, '00000003', NULL, '0', '1', '1', '100', '60', '2022-04-17', 'A', 'admin', '18-04-2022 01:10:53', NULL, NULL, NULL, NULL, '2022-04-17 19:41:16'),
(4, '00000004', NULL, '0', '1', '1', '100', '60', '2022-04-18', 'A', 'admin', '18-04-2022 07:45:22', NULL, NULL, NULL, NULL, '2022-04-18 02:15:41'),
(5, '00000005', NULL, NULL, '2', '1', '250', '60', '2022-04-17', 'A', 'admin', '18-04-2022 08:07:35', NULL, NULL, NULL, NULL, '2022-04-18 02:37:35'),
(6, '00000006', NULL, NULL, '1', '1', '100', '60', '2022-04-18', 'A', 'admin', '18-04-2022 09:30:47', NULL, NULL, NULL, NULL, '2022-04-18 04:00:47'),
(7, '00000007', NULL, NULL, '1', '1', '100', '60', '2022-04-18', 'A', 'admin', '18-04-2022 09:33:02', NULL, NULL, NULL, NULL, '2022-04-18 04:03:02'),
(8, '00000008', NULL, '0', '1', '1', '100', '60', '2022-04-18', 'A', 'admin', '18-04-2022 09:33:49', NULL, NULL, NULL, NULL, '2022-04-18 04:04:12'),
(9, '00000009', NULL, '0', '1', '1', '100', '60', '2022-04-18', 'A', 'admin', '18-04-2022 09:35:15', NULL, NULL, NULL, NULL, '2022-04-18 04:05:33'),
(10, '00000010', NULL, NULL, '1', '1', '100', '60', '2022-04-18', 'A', 'admin', '18-04-2022 09:36:00', NULL, NULL, NULL, NULL, '2022-04-18 04:06:00'),
(11, '00000011', NULL, NULL, '2', '1', '250', '60', '2022-04-18', 'A', 'admin', '18-04-2022 09:41:30', NULL, NULL, NULL, NULL, '2022-04-18 04:11:30'),
(12, '00000012', NULL, '0', '3', '1', '7200', '1440', '2022-04-18', 'A', 'admin', '18-04-2022 09:41:45', NULL, NULL, NULL, NULL, '2022-04-18 04:12:06'),
(13, '00000013', NULL, '0', '1', '1', '100', '60', '2022-04-18', 'A', 'admin', '18-04-2022 07:35:21', NULL, NULL, NULL, NULL, '2022-04-18 14:05:44'),
(14, '00000014', NULL, '0', '1', '1', '200', 'l20', '2022-04-18', 'A', 'admin', '18-04-2022 08:37:26', NULL, NULL, NULL, NULL, '2022-04-18 15:07:45'),
(15, '00000015', NULL, '0', '1', '1', '2400', '1440', '2022-05-06', 'A', 'admin', '24-05-2022 07:34:44', NULL, NULL, NULL, NULL, '2022-05-24 02:06:18');

-- --------------------------------------------------------

--
-- Table structure for table `elec_center`
--

CREATE TABLE `elec_center` (
  `id` int(100) NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `icon` varchar(250) DEFAULT NULL,
  `status` varchar(12) DEFAULT NULL,
  `added_on` varchar(150) DEFAULT NULL,
  `added_by` varchar(150) DEFAULT NULL,
  `modified_on` varchar(150) DEFAULT NULL,
  `modified_by` varchar(150) DEFAULT NULL,
  `deleted_on` varchar(150) DEFAULT NULL,
  `deleted_by` varchar(150) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `elec_center`
--

INSERT INTO `elec_center` (`id`, `title`, `icon`, `status`, `added_on`, `added_by`, `modified_on`, `modified_by`, `deleted_on`, `deleted_by`, `timestamp`) VALUES
(1, 'Vile Parle', 'category_img/center_1.-1650220846.jpg', 'A', '18-04-2022 12:10:46', 'admin', NULL, NULL, NULL, NULL, '2022-04-17 18:40:46'),
(2, 'Jogeshwari', 'category_img/center_5.-1650220866.jpg', 'A', '18-04-2022 12:11:06', 'admin', NULL, NULL, NULL, NULL, '2022-04-17 18:41:06'),
(3, 'Byculla', 'category_img/center_2.-1650220880.jpg', 'A', '18-04-2022 12:11:20', 'admin', NULL, NULL, NULL, NULL, '2022-04-17 18:41:20'),
(4, 'Borivali', 'category_img/center_3.-1650220912.jpg', 'A', '18-04-2022 12:11:52', 'admin', NULL, NULL, NULL, NULL, '2022-04-17 18:41:52'),
(5, 'Malad', 'category_img/malad.-1650221068.jpg', 'A', '18-04-2022 12:14:28', 'admin', NULL, NULL, NULL, NULL, '2022-04-17 18:44:28'),
(6, 'Navi Mumbai', 'category_img/center_4.-1650221097.jpg', 'A', '18-04-2022 12:14:57', 'admin', NULL, NULL, NULL, NULL, '2022-04-17 18:44:57');

-- --------------------------------------------------------

--
-- Table structure for table `elec_user`
--

CREATE TABLE `elec_user` (
  `id` int(100) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(150) DEFAULT NULL,
  `status` varchar(12) DEFAULT NULL,
  `added_on` varchar(150) DEFAULT NULL,
  `added_by` varchar(150) DEFAULT NULL,
  `modified_on` varchar(150) DEFAULT NULL,
  `modified_by` varchar(150) DEFAULT NULL,
  `deleted_on` varchar(150) DEFAULT NULL,
  `deleted_by` varchar(150) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `elec_user`
--

INSERT INTO `elec_user` (`id`, `name`, `email`, `password`, `status`, `added_on`, `added_by`, `modified_on`, `modified_by`, `deleted_on`, `deleted_by`, `timestamp`) VALUES
(1, 'Omkar', 'omkar@gmail.com', '4319975b32672706d0d55612c3612afbf36873f4fc5e8ef1020103a88a441564', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2022-04-17 19:01:56'),
(2, 'Project', 'omkarpawar062001@gmail.com', '4319975b32672706d0d55612c3612afbf36873f4fc5e8ef1020103a88a441564', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2022-04-18 04:10:59'),
(3, 'omkarnipane01', 'omkarnipane01@gmail.com', '6fa8a9dde7a399b719171c29e7a1de820ee22951989ecb2a50e09374e6060478', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2022-08-26 14:37:41'),
(4, 'Ash12', 'omkarnipane0@gmail.com', 'b00d926404a96d81ca1680c59765e800aceb1610099211b8f5bde831b0d132b4', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-05 05:45:19'),
(5, 'ashishsable1', 'ashishsable246@gmail.com', 'd178cf20a87e4b7b5bab59690ed6cbd17871b529df6015cf377c4b0c1d284d3b', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-13 13:33:00'),
(6, 'ashishsable1', 'ashishsable246@gmail.com', 'd178cf20a87e4b7b5bab59690ed6cbd17871b529df6015cf377c4b0c1d284d3b', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-13 13:33:01'),
(7, 'ashishsable1', 'ashishsable246@gmail.com', 'd178cf20a87e4b7b5bab59690ed6cbd17871b529df6015cf377c4b0c1d284d3b', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-13 13:33:02'),
(8, 'ashishsable1', 'ashishsable246@gmail.com', 'd178cf20a87e4b7b5bab59690ed6cbd17871b529df6015cf377c4b0c1d284d3b', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2022-12-13 13:33:26'),
(9, 'ashish25', 'ashishsable246@gmail.com', 'cc7313d4a413d8247de743ec83bc830157e2c9c05417166c24c58ec0c0b32ec6', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 02:32:42'),
(10, 'ash72@gmail.com', 'ash72@gmail.com', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2023-02-26 14:55:22'),
(11, 'ash72@gmail.com', 'ash72@gmail.com', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2023-02-26 14:55:39'),
(12, 'ajinkya12@gmail.com', 'ajinkya123@gmail.com', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2023-03-20 04:44:49'),
(13, 'omkar72@gmail.com', 'omkar72@gmail.com', '1718c24b10aeb8099e3fc44960ab6949ab76a267352459f203ea1036bec382c2', 'A', NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-26 17:25:19');

-- --------------------------------------------------------

--
-- Table structure for table `elec_vechicle`
--

CREATE TABLE `elec_vechicle` (
  `id` int(100) NOT NULL,
  `center_id` varchar(150) DEFAULT NULL,
  `title` varchar(300) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(12) DEFAULT NULL,
  `added_on` varchar(150) DEFAULT NULL,
  `added_by` varchar(150) DEFAULT NULL,
  `modified_on` varchar(150) DEFAULT NULL,
  `modified_by` varchar(150) DEFAULT NULL,
  `deleted_on` varchar(150) DEFAULT NULL,
  `deleted_by` varchar(150) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `elec_vechicle`
--

INSERT INTO `elec_vechicle` (`id`, `center_id`, `title`, `price`, `image`, `description`, `status`, `added_on`, `added_by`, `modified_on`, `modified_by`, `deleted_on`, `deleted_by`, `timestamp`) VALUES
(1, '1', 'Hamilton', '100', 'blog_img/cycle_2.-1650221505.jpg', '<p>Non-Gear</p>\r\n\r\n<p>Green Colour with disc brakes</p>\r\n\r\n<p>A bottle holder</p>\r\n', 'A', '18-04-2022 12:21:45', 'admin', NULL, NULL, NULL, NULL, '2022-04-17 18:51:45'),
(2, '2', 'Hercules', '250', 'blog_img/cycle_hercules.-1650221622.jpg', '<p>Non-Gear</p>\r\n\r\n<p>Black Colour with Disc brakes</p>\r\n', 'A', '18-04-2022 12:23:42', 'admin', NULL, NULL, NULL, NULL, '2022-04-17 18:53:42'),
(3, '3', 'Hero', '300', 'blog_img/cycle_hero.-1650221752.jpg', '<p>Non-Gear</p>\r\n\r\n<p>Orange Colour No Disc brakes</p>\r\n\r\n<p>A bottle holder</p>\r\n', 'A', '18-04-2022 12:25:52', 'admin', NULL, NULL, NULL, NULL, '2022-04-17 18:55:52'),
(4, '6', 'Electric Cycle', '750', 'blog_img/elec_cycle_3.-1650221821.jpg', '<p>Electric Cycle HI-tech</p>\r\n\r\n<p>4 hours battery capacity</p>\r\n', 'A', '18-04-2022 12:27:01', 'admin', NULL, NULL, NULL, NULL, '2022-04-17 18:57:01'),
(5, '5', 'Commercial Electric cycle ', '150', 'blog_img/elec_cycle_2.-1650221967.jpg', '<p>A basket for luggage</p>\r\n\r\n<p>8 hours battery capacity</p>\r\n', 'A', '18-04-2022 12:29:27', 'admin', '18-04-2022 12:43:10', 'admin', NULL, NULL, '2022-04-17 19:13:10'),
(6, '2', 'Mountain Electric cycle', '170', 'blog_img/elec_cycle.-1650222075.jpg', '<p>A mountainer electric bike</p>\r\n\r\n<p>24 Gears speed</p>\r\n\r\n<p>&nbsp;</p>\r\n', 'A', '18-04-2022 12:31:15', 'admin', '18-04-2022 12:42:59', 'admin', NULL, NULL, '2022-04-17 19:12:59'),
(7, '2', 'Hero', 'ddd', 'blog_img/elec_cycle.-1650254991.jpg', '<p>cycle</p>\r\n', 'A', '18-04-2022 09:39:51', 'admin', NULL, NULL, NULL, NULL, '2022-04-18 04:09:51');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `book_id` int(100) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `payment_status` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `added_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `signup_admin`
--

CREATE TABLE `signup_admin` (
  `id` int(100) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup_admin`
--

INSERT INTO `signup_admin` (`id`, `username`, `email`, `password`, `status`) VALUES
(1, 'Admin123', 'Admin123@gmail.com', 'e86f78a8a3caf0b60d8e74e5942aa6d86dc150cd3c03338aef25b7d2d7e3acc7', 'A'),
(2, 'Superadmin', 'omkarpawar982@gmail.com', '4c0a66f5cf213ea6a879a4215e781f6f3113b3b087f6720e980b3f8bca25125c', 'A'),
(3, 'ash72@gmail.com', 'ash72@gmail.com', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', 'A'),
(4, 'ash72@gmail.com', 'ash72@gmail.com', '1718c24b10aeb8099e3fc44960ab6949ab76a267352459f203ea1036bec382c2', 'A'),
(5, 'ash72@gmail.com', 'ash72@gmail.com', '1718c24b10aeb8099e3fc44960ab6949ab76a267352459f203ea1036bec382c2', 'A'),
(6, 'harsh', 'harshmhamunkar71@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'A'),
(7, 'harsh', 'harshmhamunkar71@gmail.com', 'c38777d1619a83b0ee9e6e23868bb47b29f81875090a0b5d4e607263df35fec1', 'A'),
(8, 'harsh', 'harshmhamunkar71@gmail.com', '688787d8ff144c502c7f5cffaafe2cc588d86079f9de88304c26b0cb99ce91c6', 'A'),
(9, 'harsh', 'harshmhamunkar71@gmail.com', '688787d8ff144c502c7f5cffaafe2cc588d86079f9de88304c26b0cb99ce91c6', 'A'),
(10, 'harsh', 'harshmhamunkar71@gmail.com', '688787d8ff144c502c7f5cffaafe2cc588d86079f9de88304c26b0cb99ce91c6', 'A'),
(11, 'harsh', 'harshmhamunkar71@gmail.com', '688787d8ff144c502c7f5cffaafe2cc588d86079f9de88304c26b0cb99ce91c6', 'A'),
(12, 'harsh', 'harshmhamunkar71@gmail.com', '2062f80093066633876b542212c496501a5e79523cc4ea9b28667dff065afd8f', 'A'),
(13, 'harsh', 'harshmhamunkar71@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'A'),
(14, 'harsh', 'harshmhamunkar71@gmail.com', '688787d8ff144c502c7f5cffaafe2cc588d86079f9de88304c26b0cb99ce91c6', 'A'),
(15, 'harsh', 'harshmhamunkar71@gmail.com', '688787d8ff144c502c7f5cffaafe2cc588d86079f9de88304c26b0cb99ce91c6', 'A'),
(16, 'harsh', 'harshmhamunkar71@gmail.com', '688787d8ff144c502c7f5cffaafe2cc588d86079f9de88304c26b0cb99ce91c6', 'A'),
(17, 'harsh', 'harshmhamunkar71@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'A'),
(18, 'harsh', 'harshmhamunkar71@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'A'),
(19, 'harsh', 'harshmhamunkar71@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'A'),
(20, 'harsh', 'harshmhamunkar71@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'A'),
(21, 'harsh', 'harshmhamunkar71@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'A'),
(22, 'harsh', 'harshmhamunkar71@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'A'),
(23, 'harsh', 'harshmhamunkar71@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `signup_user`
--

CREATE TABLE `signup_user` (
  `id` int(200) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup_user`
--

INSERT INTO `signup_user` (`id`, `username`, `email`, `password`, `status`) VALUES
(1, 'ruchi', 'omkarpawar982@gmail.com', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `id` int(100) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `username`, `password`, `status`) VALUES
(1, 'user testing', '8776f108e247ab1e2b323042c049c266407c81fbad41bde1e8dfc1bb66fd267e', 'A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `basic_details`
--
ALTER TABLE `basic_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_ride`
--
ALTER TABLE `book_ride`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `centre_details`
--
ALTER TABLE `centre_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cycle_details`
--
ALTER TABLE `cycle_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `elec_admin`
--
ALTER TABLE `elec_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `elec_blog`
--
ALTER TABLE `elec_blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `elec_bookings`
--
ALTER TABLE `elec_bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `elec_center`
--
ALTER TABLE `elec_center`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `elec_user`
--
ALTER TABLE `elec_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `elec_vechicle`
--
ALTER TABLE `elec_vechicle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup_admin`
--
ALTER TABLE `signup_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup_user`
--
ALTER TABLE `signup_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `basic_details`
--
ALTER TABLE `basic_details`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `book_ride`
--
ALTER TABLE `book_ride`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `centre_details`
--
ALTER TABLE `centre_details`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cycle_details`
--
ALTER TABLE `cycle_details`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `elec_admin`
--
ALTER TABLE `elec_admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `elec_blog`
--
ALTER TABLE `elec_blog`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `elec_bookings`
--
ALTER TABLE `elec_bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `elec_center`
--
ALTER TABLE `elec_center`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `elec_user`
--
ALTER TABLE `elec_user`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `elec_vechicle`
--
ALTER TABLE `elec_vechicle`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `signup_admin`
--
ALTER TABLE `signup_admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `signup_user`
--
ALTER TABLE `signup_user`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) NOT NULL DEFAULT '',
  `user` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) NOT NULL,
  `col_name` varchar(64) NOT NULL,
  `col_type` varchar(64) NOT NULL,
  `col_length` text DEFAULT NULL,
  `col_collation` varchar(64) NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) DEFAULT '',
  `col_default` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `transformation` varchar(255) NOT NULL DEFAULT '',
  `transformation_options` varchar(255) NOT NULL DEFAULT '',
  `input_transformation` varchar(255) NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) NOT NULL,
  `settings_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL,
  `export_type` varchar(10) NOT NULL,
  `template_name` varchar(64) NOT NULL,
  `template_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db` varchar(64) NOT NULL DEFAULT '',
  `table` varchar(64) NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) NOT NULL,
  `item_name` varchar(64) NOT NULL,
  `item_type` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) NOT NULL DEFAULT '',
  `master_table` varchar(64) NOT NULL DEFAULT '',
  `master_field` varchar(64) NOT NULL DEFAULT '',
  `foreign_db` varchar(64) NOT NULL DEFAULT '',
  `foreign_table` varchar(64) NOT NULL DEFAULT '',
  `foreign_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `search_name` varchar(64) NOT NULL DEFAULT '',
  `search_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `display_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `prefs` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text NOT NULL,
  `schema_sql` text DEFAULT NULL,
  `data_sql` longtext DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2024-02-28 04:55:37', '{\"Console\\/Mode\":\"collapse\"}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) NOT NULL,
  `tab` varchar(64) NOT NULL,
  `allowed` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) NOT NULL,
  `usergroup` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
