<div class="posts">
    <?php
    $query = "SELECT * FROM `cycle_details` WHERE STATUS='A'";
    $stmt = $db_con->prepare($query);
    $stmt->execute();
    $count = $stmt->rowCount();
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>
    <?php
    for ($i = 0; $i < $count; $i++) {
        $sr = $i + 1;
        $id = $row[$i]['id'];
        ?>
        <div class="post">
            <div class="post__thumb">
                <a href="cycle_details.php?date=<?= date('his') ?>&id=<?= $id ?>"><img src="../<?= $row[$i]['image'] ?>" alt="" title=""/></a>
            </div>
            <div class="post__details">
                <h4 class="post__title"><a href="cycle_details.php?date=<?= date('his') ?>&id=<?= $id ?>"><?= $row[$i]['cycle_name'] ?></a></h4>
                <a href="cycle_details.php?date=<?= date('his') ?>&id=<?= $id ?>" class="post__more button button--blue button--ex-small">VIEW IT</a>
                <a href="delete_cycle.php?id=<?= $id ?>" class="post__delete button button--red button--ex-small">DELETE</a>
            </div>
        </div>
        <?php
    }
    ?>
</div>