<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.vegathemes.net/gomobile/demos/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:55 GMT -->
<head>
<?php include('header_links.php'); ?>
</head>
<body>
	
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--main" data-page="contact">
	
	<!-- HEADER -->
	<header class="header header--page header--fixed">	
		<div class="header__inner">	
		<div class="header__icon open-panel" data-panel="right" data-arrow="left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/user.svg" alt="" title="logo"/><span></span><span></span><span></span><span></span><span></span><span></span></a></div>
			<div class="header__logo header__logo--text"><a href="#"><b>PADDLE UP & TRAVERSE</b></a></div>	
			<div class="header__icon open-panel" data-panel="right" data-arrow="left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/logout.svg" alt="" title="Login"/></div>
                </div>
	</header>
	
	<!-- PAGE CONTENT -->
	<div class="page__content page__content--with-header">
		<h2 class="page__title">Contact Form</h2>
              	  
		<div class="fieldset">
			<h2 id="Note"></h2>
			<div class="form">
				<form class="" id="ContactForm" method="post" action="#">
					<div class="form__row">
						<input type="text" name="ContactName" value="" class="form__input required" placeholder="Name" />
					</div>
					<div class="form__row">
						<input type="text" name="ContactEmail" value="" class="form__input email required" placeholder="Email" />
					</div>
					<div class="form__row">
						<div class="form__select">
							<select name="ContactSelect" class="required">
								<option value="" disabled selected>Select options</option>
								<option value="1">select one</option>
								<option value="2">select two</option>
								<option value="3">select three</option>
								<option value="4">select four</option>
								<option value="5">select five</option>
							</select>
						</div>
					</div>	
					<div class="form__row">
						<textarea name="ContactComment" class="form__textarea required" placeholder="TextArea"></textarea>
					</div>	

					<div class="form__row mt-20">
						<input type="submit" name="submit" class="form__submit button button--green button--full" id="submit" value="SUBMIT" />
						<input class="" type="hidden" name="to"  value="youremail@website.com" />
						<input class="" type="hidden" name="ContactSubject" value="Contacf form message" />
						<label id="loader" style="display:none;"><div id="loader-animation"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></label>
					</div>
				</form>
			</div>
		</div>
		<h2 class="page__title">Location Map Example</h2>
		<div class="fieldset">
		  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d193578.74109041138!2d-73.97968099999997!3d40.70331274999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York+NYC%2C+New+York%2C+Statele+Unite+ale+Americii!5e0!3m2!1sro!2s!4v1425027721891" width="100%" height="200" frameborder="0" style="border:0"></iframe> 
		 </div> 
		
	</div>
			  



</div>
<!-- PAGE END -->


<!-- Social Icons Popup -->
<div id="popup-social"></div>
 
<!-- Alert --> 
<div id="popup-alert"></div> 
 

<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/swiper-init-swipe.html"></script>
<script src="js/email.js"></script>
<script src="js/jquery.custom.js"></script>
</body>

<!-- Mirrored from www.vegathemes.net/gomobile/demos/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:55 GMT -->
</html>