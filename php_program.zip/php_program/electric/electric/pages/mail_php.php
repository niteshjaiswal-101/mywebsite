<?php
include('https://cubecle.com/team/projects/send_mail.php');
if(isset($_GET['email'])){
    $email = $_GET['email'];
//    $from = "paddleupandtraverse@gmail.com"; // sender
   $subject = " My cron is working";
   $message = "My first Cron  :)";

   // message lines should not exceed 70 characters (PHP rule), so wrap it

   $message = wordwrap($message, 70);

   // send mail

//    ini_set("SMTP","localhost");
//    ini_set("smtp_port","25");
//    ini_set("sendmail_from","paddleupandtraverse@gmail.com");
//    ini_set("sendmail_path", "E:\xampp\sendmail\sendmail.exe -t");

   send_mail_php("tarunkute131203@gmail.com",$subject,$msg);

   echo "Thank you for sending us feedback";

}
   
?>