<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.vegathemes.net/gomobile/demos/signup.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:55 GMT -->
<head>
<?php include('header_links.php'); ?>
<style>
	.bg {
		background-image: url("../assets/images/slider/22.jpg");
	}
   
	#snackbar {
  visibility: hidden;
  min-width: 250px;
  margin-left: -145px;
  background-color: #333;
  color: #fff;
  text-align: center;
  border-radius: 2px;
  padding: 16px;
  position: fixed;
  z-index: 1;
  left: 50%;
  bottom: 30px;
  font-size: 17px;
}

#snackbar.show {
  visibility: visible;
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

@-webkit-keyframes fadein {
  from {bottom: 0; opacity: 0;} 
  to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
  from {bottom: 0; opacity: 0;}
  to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {bottom: 30px; opacity: 1;} 
  to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
  from {bottom: 30px; opacity: 1;}
  to {bottom: 0; opacity: 0;}
}

</style> 
</head>
<body>
	
<div class="page page--login" data-page="login">
<?php
         include('connection.php');         
         $db_con = getDB();
		//  print_r($_POST);
      ?>
	
	<!-- HEADER -->
	<header class="header header--fixed">	
		<div class="header__inner">	
			<div class="header__icon"><a href="splash.html"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/gray/arrow-back.svg" alt="" title=""/></a></div>	
                </div>
	</header>
	<?php
   if (isset($_POST['register'])) {
      $username = $_POST['username'];
	  $email = $_POST['email'];
      $password = $_POST['password'];
      $hash_pass = trim(hash('sha256', $password));
      $stm = $db_con->prepare("INSERT INTO `ash`(`name`, `email`, `password`, `status`) VALUES (:username, :email, :password, 'A')");
        $stm->bindParam(":username", $username, PDO::PARAM_STR);
        $stm->bindParam(":email", $email, PDO::PARAM_STR);
        $stm->bindParam(":password", $hash_pass, PDO::PARAM_STR);
        $stm->execute();
        // $last_id = $db_con->lastInsertId();
        // $cat_id = $last_id;
        $count = $stm->rowCount();
        if ($count > 0) {

        //  $_SESSION['project'] = $row[0]['id'];
         echo  "<script>window.location.href = 'login.php'</script>";
      	} 
	  	else 
		{
         echo "<div id='snackbar'>Incorrect username or password</div>";
   ?>
		<script>
            // Get the snackbar DIV
            var x = document.getElementById("snackbar");

            // Add the "show" class to DIV
            x.className = "show";

            // After 3 seconds, remove the show class from DIV
            setTimeout(function() {
               x.className = x.className.replace("show", "");
            }, 3000);
         </script>
   <?php
   }
}

   ?>
    <div class="login bg">
		<div class="login__content">
      <!-- <a href="signup_admin.php"><p style="color: #fff">Register as admin?</p> -->
			<h2 class="login__title" style="font-size: 25px; color:#000;" >USER REGISTER</h2>
				<div class="login-form">
					<form id="LoginForm" method="post">
						<div class="login-form__row">
							<label class="login-form__label" style="color: #fff;">Username</label>
							<input type="text" name="username" pattern="[A-Za-z,0-9]{2,}" placeholder="username" class="login-form__input required" />
						</div>
						<div class="login-form__row">
							<label class="login-form__label" style="color: #fff;">Email</label>
							<input type="text" name="email" id="mail" placeholder="Email" class="login-form__input required email" />
						</div>
						<div class="login-form__row">
							<label class="login-form__label" style="color: #fff;">Password</label>
							<input type="password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" value="" placeholder="Password" class="login-form__input required" />
						</div>
						<div class="login-form__row">
							<input type="submit" name="register" class="login-form__submit button button--blue button--full" id="submit" value="SIGN UP" />
						</div>
					</form>	
               <div class="login-form__bottom">
						<p style="color: #fff">Already have an account?</p>
						<a href="login.php" class="button button--green button--full" onclick>LOGIN</a>
                  <!-- <a href="admin_login.php"><p style="color: #fff">Login as admin?</p> -->
					</div>
				</div>
		</div>
    </div>
			  


</div>
<!-- PAGE END -->
   
<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/jquery.custom.js"></script>

<script>
         $("#mail").keyup(function(e) {
            var regex = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]+$/; 
            if (regex.test(this.value) !== true)
            this.value = this.value.replace(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]+/, '');
         });
</script>

</body>

<!-- Mirrored from www.vegathemes.net/gomobile/demos/signup.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:55 GMT -->
</html>