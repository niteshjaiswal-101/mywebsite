<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

require ('PHPMailerAutoload.php');
function send_mail($email,$sub,$message)
{ 
		$mail= new PHPMailer;
		$mail->isSMTP();
		$mail->Host='smtp.hostinger.in';
		$mail->Port=587;
		$mail->SMTPAuth=true;
		$mail->SMTPSecure='tls';
		$mail->Username='mails@cubecle.com';
		$mail->Password='Cube@Mail-2022_Mailer';
		$mail->setFrom('mails@cubecle.com');//omkarpawar982@gmail.com
		$mail->addAddress($email);
		$mail->addReplyTo('mails@cubecle.com');  
		$mail->Subject=$sub; 
		$mail->MsgHTML($message);
		if(!$mail->send()){
			return "MailNotSent"; //mail not sent 
		}
		else{
			return "MailSent"; //mail sent 
		}
}

function send_mail_login($email,$sub,$message)
{ 
		$mail= new PHPMailer;
		$mail->isSMTP();
		$mail->Host='smtp.hostinger.in';
		$mail->Port=587;
		$mail->SMTPAuth=true;
		$mail->SMTPSecure='tls';
		$mail->Username='mails@cubecle.com';
		$mail->Password='Cube@Mail-2022_Mailer';
		$mail->setFrom('omkarpawar982@gmail.com');//omkarpawar982@gmail.com
		$mail->addAddress($email);
		$mail->addReplyTo('mails@cubecle.com');  
		$mail->Subject=$sub; 
		$mail->MsgHTML($message);
		if(!$mail->send()){
			return "MailNotSent"; //mail not sent 
		}
		else{
			return "MailSent"; //mail sent 
		}
}
?>