<?php
session_start();
include('connection.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM `cycle_details` WHERE `id` = ?";
    $stmt = $db_con->prepare($query);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    header('Location: sliders.php');
}
?>