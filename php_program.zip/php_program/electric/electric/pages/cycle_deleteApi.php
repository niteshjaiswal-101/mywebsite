<?php require('connection.php'); 
$db_con = getDB();

if(isset($_GET['id'])) //events
{
    $id = $_GET['id'];
    $status='D';
    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-Y h:i:s');
    //    $deleted_by = 'abc';
    // $added_by
    $query="UPDATE `subcategory` SET `status`=:status WHERE id=:id";
    $stmt = $db_con->prepare($query);
    $stmt->bindParam(":id", $id,PDO::PARAM_STR);
    $stmt->bindParam(":status", $status,PDO::PARAM_STR);
    $stmt->execute();
    // $stmp->debugDumpParams();
    
   
            
        if ($stmt->rowCount() >= 0){
              echo "<script> alert('Deleted Successfully');</script>"; 
              header('Location: actions.php?status=success');
              

        }
        else
        {
             echo "<script> alert('Delete Failed'); </script>";
              header('Location: actions.php?status=failed');
              
        }
}

?>