<?php   
   session_start();
   // if(!isset($_SESSION['admin']) && empty($_SESSION['admin'])){
   //   echo "<script>window.location.href = 'index.php'</script>";
   // }
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.vegathemes.net/gomobile/demos/main.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:37 GMT -->
<head>
<?php include('header_links.php'); ?>  
</head>
<body>
	
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--main" data-page="main">
	
	<!-- HEADER -->
	<header class="header header--page header--fixed">	
		<div class="header__inner">	
        <div class="header__icon"></div>
			<div class="header__logo header__logo--text"><a href="#"><b style="font-size:20px;">PADDLE UP & TRAVERSE</b></a></div>	
			<div class="header__icon open-panel" data-panel="right" data-arrow="left"><a href="logout.php"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/logout.svg" alt="" title="Logout"/></a></div>
                </div>
	</header>
	
	
	<!-- PAGE CONTENT -->
	<div class="page__content page__content--with-header page__content--with-bottom-nav">
	      <h2 class="page__title">menu </h2>   
              <div class="cards cards--11">
			  <div class="card">
				  <div class="card__icon"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/blue/lock.svg" alt="" title=""/></div>
				  <div class="card__details">
					  <h4 class="card__title">Home</h4>
				  </div>
				  <div class="card__more"><a class="button button--white button--ex-small" href="#">VIEW</a></div>
			  </div>
			  <div class="card">
				  <div class="card__icon"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/blue/blocks.svg" alt="" title=""/></div>
				  <div class="card__details">
					  <h4 class="card__title">upload Cycles</h4>
				  </div>
				  <div class="card__more"><a class="button button--white button--ex-small" href="admin_cycle.php">VIEW</a></div>
			  </div>
			  <div class="card">
				  <div class="card__icon"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/blue/blocks.svg" alt="" title=""/></div>
				  <div class="card__details">
					  <h4 class="card__title"> Cycles</h4>
				  </div>
				  <div class="card__more"><a class="button button--white button--ex-small" href="cycle_slide.php">VIEW</a></div>
			  </div>
			  <div class="card">
				  <div class="card__icon"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/blue/slider.svg" alt="" title=""/></div>
				  <div class="card__details">
					  <h4 class="card__title">Upload Centres</h4>
				  </div>
				  <div class="card__more"><a class="button button--white button--ex-small" href="admin_centre.php">VIEW</a></div>
			  </div>
			  <div class="card">
				  <div class="card__icon"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/blue/slider.svg" alt="" title=""/></div>
				  <div class="card__details">
					  <h4 class="card__title">Centres</h4>
				  </div>
				  <div class="card__more"><a class="button button--white button--ex-small" href="centre_slide.php">VIEW</a></div>
			  </div>
			  <div class="card">
				  <div class="card__icon"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/blue/news.svg" alt="" title=""/></div>
				  <div class="card__details">
					  <h4 class="card__title">User Table</h4>
				  </div>
				   <div class="card__more"><a class="button button--white button--ex-small" href="user_table.php">VIEW</a></div>
			  </div>
			  <div class="card">
				  <div class="card__icon"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/blue/home.svg" alt="" title=""/></div>
				  <div class="card__details">
					  <h4 class="card__title">Subscription Plan</h4>
				  </div>
				  <div class="card__more"><a class="button button--white button--ex-small" href="subscribe_plan.php">VIEW</a></div>
			  </div>
			  <div class="card">
				  <div class="card__icon"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/blue/cart.svg" alt="" title=""/></div>
				  <div class="card__details">
					  <h4 class="card__title">Profile</h4>
				  </div>
				  <div class="card__more"><a class="button button--white button--ex-small" href="shop.html">VIEW</a></div>
			  </div>
			  <div class="card">
				  <div class="card__icon"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/blue/photos.svg" alt="" title=""/></div>
				  <div class="card__details">
					  <h4 class="card__title">Contact</h4>
				  </div>
				   <div class="card__more"><a class="button button--white button--ex-small" href="contact.php">VIEW</a></div>
			  </div>
			  <div class="card">
				  <div class="card__icon"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/blue/popup.svg" alt="" title=""/></div>
				  <div class="card__details">
					  <h4 class="card__title">Logout</h4>
				  </div>
				   <div class="card__more"><a class="button button--white button--ex-small" href="logout.php">VIEW</a></div>
			  </div>
              </div>

			  
	</div>
			  



</div>
<!-- PAGE END -->

<!-- Bottom navigation -->
<!-- <div id="bottom-toolbar" class="bottom-toolbar"></div> -->

<!-- Social Icons Popup -->
<!-- <div id="popup-social"></div> -->
 
<!-- Alert --> 
<!-- <div id="popup-alert"></div>   -->

<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/swiper-init.js"></script>
<script src="js/jquery.custom.js"></script>
</body>

<!-- Mirrored from www.vegathemes.net/gomobile/demos/main.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:43 GMT -->
</html>