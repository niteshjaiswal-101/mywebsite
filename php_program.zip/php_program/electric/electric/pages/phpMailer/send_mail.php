<?php 
function send_email($email,$subject,$msg)
{ 
		echo 'Omkar';
		require ('PHPMailerAutoload.php');
		$mail= new PHPMailer;

		$mail->isSMTP();
		$mail->Host='smtp.hostinger.in';
		$mail->Port=587;
		$mail->SMTPAuth=true;
		$mail->SMTPSecure='tls';
		$message=$msg;
		$mail->Username='omkarpawar982@gmail.com';
		$mail->Password='INDIA@0610';
// 		'5auxW2f=C';
		$mail->setFrom('omkarpawar982@gmail.com');
		$mail->addAddress($email);
		// $mail->addReplyTo($email); 
		// $mail->isHTML(true);
		$mail->Subject=$subject; 
		$mail->MsgHTML($message);
		//$mail->Body=
// echo $mail->send();
		if(!$mail->send()){
			return "MailNotSent"; 
		}
		else{
			return "MailSent"; 
		}
		     

}
// echo  send_email('hamzaindorwala3@gmail.com',"Hey Mail test Here","Hii Hamza, we are testing email with swati and omkar");
?>