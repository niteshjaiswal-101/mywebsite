<?php 
// include('phpMailer/mail1.php'); 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); ?>
<?php
send_email();
function send_email()
{ 
		// echo 'Omkar';
		require ('PHPMailerAutoload.php');
		$mail= new PHPMailer;
		$email = $_GET['email'];
		$mail->isSMTP();
		$mail->Host='smtp.hostinger.in';
		$mail->Port=587;
		$mail->SMTPAuth=true;
		$mail->SMTPSecure='tls';
		$message="TEsting";
		$subject = "hii";	
		$mail->Username='paddleupandtraverse@gmail.com';
		$mail->Password='paddleupandtraverse2430';
// 		'5auxW2f=C';
		$mail->setFrom('paddleupandtraverse@gmail.com');
		$mail->addAddress($email);
		// $mail->addReplyTo($email); 
		// $mail->isHTML(true);
		$mail->Subject=$subject; 
		$mail->MsgHTML($message);
		//$mail->Body=
// echo $mail->send();
		if(!$mail->send()){
			return "MailNotSent"; 
		}
		else{
			return "MailSent"; 
		}
		     

}
// echo  send_email('hamzaindorwala3@gmail.com',"Hey Mail test Here","Hii Hamza, we are testing email with swati and omkar");

// function send_fp($email)
// {
// 		date_default_timezone_set('Asia/Kolkata');
// 		$date=date("d-m-y");
// 		$time=date("h-i-s");
// 		$code=date("dmshiyd");
		
// 		require ('PHPMailerAutoload.php');
// 		$mail= new PHPMailer;

// 		$mail->isSMTP();
// 		$mail->Host='smtp.hostinger.in';
// 		$mail->Port=587;
// 		$mail->SMTPAuth=true;
// 		$mail->SMTPSecure='tls';
// 		$message='Hello <br> Welcome to Paddle Up and Traverse, <br>Your request for changing password has been received. <br>Click on the link below to change password.<br> <a href="http://hamiters.com/Hamiters/Nefertari/reset_pw.php?link=qweajdh.co.in&due_date='.$date.'&code='.$code.'&email='.$email.'&time='.$time.'"> Link</a> <br><br> This is no-reply email, <br>contact support for query.';
// 		$mail->Username='paddleupandtraverse2122@gmail.com';
// 		$mail->Password='Project@2122';
// 		$mail->setFrom('paddleupandtraverse2122@gmail.com');
// 		$mail->addAddress($email);
// 		$mail->addReplyTo($email); 
// 		// $mail->isHTML(true);
// 		$mail->Subject="Request for change password"; 
// 		$mail->MsgHTML($message);
// 		//$mail->Body=

// 		if(!$mail->send()){
// 			return "MailNotSent";
			
// 			//   echo "MailNotSent"; //mail not sent 
// 		}
// 		else{
// 			return "MailSent";
// 			// echo "MailSent"; //mail sent 
			
// 		}
// 	}
		     

// }
// function send_mail_order($email)
// {

// 		require ('PHPMailerAutoload.php');
// 		$mail= new PHPMailer;

// 		$mail->isSMTP();
// 		$mail->Host='smtp.hostinger.in';
// 		$mail->Port=587;
// 		$mail->SMTPAuth=true;
// 		$mail->SMTPSecure='tls';
// 		$message='Hello <br> Welcome to Nefertari <br> Your order has been completed';
// 		$mail->Username='office@hamiters.com';
// 		$mail->Password='5auxW2f=C';
// 		$mail->setFrom('office@hamiters.com');
// 		$mail->addAddress($email);
// 		$mail->addReplyTo($email); 
// 		// $mail->isHTML(true);
// 		$mail->Subject="Order Confirmation from Nefertari"; 
// 		$mail->MsgHTML($message);
// 		//$mail->Body=

// 		if(!$mail->send()){
// 			return "MailNotSent";
			
// 			//   echo "MailNotSent"; //mail not sent 
// 		}
// 		else{
// 			return "MailSent";
// 			// echo "MailSent"; //mail sent 
			
// 		}
		     

// }

// function send_contact_mail($email,$contact_name,$subject,$cust_contact,$msg)
// {

// 		require ('PHPMailerAutoload.php');
// 		$mail= new PHPMailer;

// 		$mail->isSMTP();
// 		$mail->Host='smtp.hostinger.in';
// 		$mail->Port=587;
// 		$mail->SMTPAuth=true;
// 		$mail->SMTPSecure='tls';
// 		$message='Hello, Nefertari <br> You got a new contact query.<br>Name :'.$contact_name.'<br>Email ID :'.$email.'<br>Contact Number :'.$cust_contact.'Query: '.$msg;
// 		$mail->Username='office@hamiters.com';
// 		$mail->Password='5auxW2f=C';
// 		$mail->setFrom('office@hamiters.com');
// 		$mail->addAddress('1997aish@gmail.com');
// 		// $mail->addReplyTo($email); 
// 		// $mail->isHTML(true);
// 		$mail->Subject="Contact query for Nefertari - ".$subject; 
// 		$mail->MsgHTML($message);
// 		//$mail->Body=

// 		if(!$mail->send()){
// 			return "MailNotSent";
			
// 			//   echo "MailNotSent"; //mail not sent 
// 		}
// 		else{
// 			return "MailSent";
// 			// echo "MailSent"; //mail sent 
			
// 		}
		     

// }
?>