<?php  include('connection.php');
    include('api/mail/mail1.php');
    $db_con = getDB(); ?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from askbootstrap.com/preview/osahan-eat/admin/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 02 May 2021 03:27:30 GMT -->

<head>
    <?php include('header_links.php');

    ?>
<style>
        /* -----
SVG Icons - svgicons.sparkk.fr
----- */

        .svg-icon {
            width: 1em;
            height: 1em;
        }

        .svg-icon path,
        .svg-icon polygon,
        .svg-icon rect {
            fill: #4691f6;
        }

        .svg-icon circle {
            stroke: #4691f6;
            stroke-width: 1;
        }

        /* -----
SVG Icons - svgicons.sparkk.fr
----- */

        .svg-icon {
            width: 1em;
            height: 1em;
        }

        .svg-icon path,
        .svg-icon polygon,
        .svg-icon rect {
            fill: #4691f6;
        }

        .svg-icon circle {
            stroke: #4691f6;
            stroke-width: 1;
        }

        /*.approve{
            background-color: #28a745;
            border-color: #28a745;
            color: white;
        }*/
        #snackbar {
      visibility: hidden; /* Hidden by default. Visible on click */
      min-width: 250px; /* Set a default minimum width */
      margin-left: -125px; /* Divide value of min-width by 2 */
      background-color: #333; /* Black background color */
      color: #fff; /* White text color */
      text-align: center; /* Centered text */
      border-radius: 2px; /* Rounded borders */
      padding: 16px; /* Padding */
      position: fixed; /* Sit on top of the screen */
      z-index: 1; /* Add a z-index if needed */
      left: 50%; /* Center the snackbar */
      bottom: 30px; /* 30px from the bottom */
      }

      /* Show the snackbar when clicking on a button (class added with JavaScript) */
      #snackbar.show {
      visibility: visible; /* Show the snackbar */
      /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
      However, delay the fade out process for 2.5 seconds */
      -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
      animation: fadein 0.5s, fadeout 0.5s 2.5s;
      }

      /* Animations to fade the snackbar in and out */
      @-webkit-keyframes fadein {
      from {bottom: 0; opacity: 0;}
      to {bottom: 30px; opacity: 1;}
      }

      @keyframes fadein {
      from {bottom: 0; opacity: 0;}
      to {bottom: 30px; opacity: 1;}
      }

      @-webkit-keyframes fadeout {
      from {bottom: 30px; opacity: 1;}
      to {bottom: 0; opacity: 0;}
      }

      @keyframes fadeout {
      from {bottom: 30px; opacity: 1;}
      to {bottom: 0; opacity: 0;}
      }
    </style>
</head>

<body class="sb-nav-fixed">
    <!-- top navbar -->
    <?php include('header.php');
   
    ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
     ?>

    <div id="layoutSidenav">
        <!-- vertical header -->
        <?php
        include('vertical-header.php');
        ?>
        <div id="layoutSidenav_content">
            <main>
                <br>
                <br>
                <div class="row">
        
                    <div class="col-lg-12">
                        <div class="card mb-9">
                            <div class="card-header">

                                Category Table

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                            

                                            <div class="row">
                                                <div class="col-sm-12 col-md-6">
                                                </div>
                                                <div class="col-sm-12 col-md-6"></div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <table class="table table-bordered dataTable no-footer" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                                                        <thead>
                                                            <th>Sr No.</th>
                                                            <th>First Name</th>
                                                            <th>Last Name</th>
                                                            <th>Phone Number</th>
                                                            <th>Email</th>
                                                            <th>Password</th>
                                                            <th>Business Title</th>
                                                            <th>Shop Address</th>
                                                            <th>Pincode</th>
                                                            <th>Aadhar Number</th>
                                                            <th>Banner</th>
                                                            <th>Type</th>
                                                            <th>Actions</th>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            $query = "SELECT * FROM `user`";
                                                            $stmt = $db_con->prepare($query);
                                                            $stmt->execute();
                                                            $count = $stmt->rowCount();
                                                            $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                                            ?>
                                                           
                                                            <?php
                                                                for ($i = 0; $i < $count; $i++) {
                                                                    $sr = $i + 1;
                                                                    $id = $row[$i]['id'];
                                                                ?>
                                                                 <tr style="background-color:<?php if($row[$i]['status'] == 'A'){echo "#63ec82";} else{echo "#fb7575";} ?>">
                                                                <td><?= $sr ?></td>
                                                                <td>
                                                                    <?= $row[$i]['fname'] ?>
                                                                </td>
                                                                <td>
                                                                    <?= $row[$i]['lname'] ?>
                                                                </td>
                                                                <td>
                                                                    <?= $row[$i]['phone_number'] ?>
                                                                </td>
                                                                <td>
                                                                    <?= $row[$i]['email'] ?>
                                                                </td>
                                                                <td>
                                                                   <?= $row[$i]['password'] ?>
                                                                </td>
                                                                <td>
                                                                    <?= $row[$i]['business_title'] ?>
                                                                </td>
                                                                <td>
                                                                    <?= $row[$i]['shop_address'] ?>
                                                                </td>
                                                                <td>
                                                                    <?= $row[$i]['pin_code'] ?>
                                                                </td>
                                                                <td>
                                                                    <?= $row[$i]['aadhar_number'] ?>
                                                                </td>
                                                                <td>
                                                                    <?= $row[$i]['banner'] ?>
                                                                </td>
                                                                <td>
                                                                    <?= $row[$i]['type'] ?>
                                                                </td>
                                                                <td>
                                                                    <a ><button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#default1_<?= $i ?>">Pending</button></a><br>
                                                                    <a><br><button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#default_<?= $i ?>">Approve</button></a>                                                                    
                                                                </td>
                                                                <div class="modal" tabindex="-1" role="dialog" id="default_<?= $i ?>" aria-labelledby="myModalLabel1" aria-hidden="true">
                                                                  <div class="modal-dialog" role="document">
                                                                    <div class="modal-content">
                                                                      <div class="modal-header">
                                                                        <h5 class="modal-title" id="myModalLabel1">Approval</h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                          <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                      </div>
                                                                      <div class="modal-body">
                                                                        <h5>Are you sure you want to confirm?</h5>
                                                                      </div>
                                                                      <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Close</button>
                                                                                <a href="api/approvapi.php?date=<?= date('his') ?>&status=A&id=<?= $row[$i]['id'] ?>">
                                                                                    <button type="button" class="btn btn-outline-primary" name="approve_button" onclick="myFunction()">Approve</button>
                                                                                </a>
                                                                                
                                                                      </div>

                                                                    </div>
                                                                  </div>
                                                                </div>

                                                            <div class="modal" tabindex="-1" role="dialog" id="default1_<?= $i ?>" aria-labelledby="myModalLabel1" aria-hidden="true">
                                                                  <div class="modal-dialog" role="document">
                                                                    <div class="modal-content">
                                                                      <div class="modal-header">
                                                                        <h5 class="modal-title" id="myModalLabel1">Pending</h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                          <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                      </div>
                                                                      <div class="modal-body">
                                                                        <h5>Are you sure you want to confirm?</h5>
                                                                      </div>
                                                                      <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Close</button>
                                                                        <a href="api/approvapi.php?date=<?= date('his') ?>&status=P&id=<?= $row[$i]['id'] ?>">
                                                                            <button type="button" class="btn btn-outline-primary" onclick="myFunction1()">Pending</button>
                                                                        </a>
                                                                                
                                                                      </div>

                                                                    </div>
                                                                  </div>
                                                                </div>
                                                            </tr>
                                                            <?php 
                                                                }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <!-- footer -->
            <?php include('footer.php'); ?>
        </div>
    </div>

    <?php include('footer_links.php'); ?>
    <?php
        if(isset($_POST['approve_button'])){
        	echo "hello omkar";
            $email=$_POST['email'];
            $subject=$_POST['subject'];
            $message=$_POST['message'];
            // $contact_name=$_POST['cust_name'];
            // $cust_contact=$_POST['cust_contact'];
            send_mail($email,$subject,$message);
            if ($_GET['status'] == 'A' ) {
            	echo "hello swati";
                $subject = 'Congratulations';
                $message = 'Welcome';
                $email = send_mail();


            }else{
                $subject = 'sorry';
                $message = 'your email is pending';
                $email = send_mail();  
            }
            echo "<script>alert('Thank you for contacting. Our team will get back to you soon.');
            </script>";
        }
    ?>    
    <script>
    	 function myFunction() {
         // Get the snackbar DIV
         var x = document.getElementById("snackbar");

         // Add the "show" class to DIV
         x.className = "show";

         // After 3 seconds, remove the show class from DIV
         setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
         }

          function myFunction1() {
         // Get the snackbar DIV
         var x = document.getElementById("snackbar");

         // Add the "show" class to DIV
         x.className = "show";

         // After 3 seconds, remove the show class from DIV
         setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
         }
    </script>

</body>
</html>