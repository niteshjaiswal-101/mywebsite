<?php   
   session_start();
   if(!isset($_SESSION['dixit_mldcc']) && empty($_SESSION['dixit_mldcc'])){
     echo "<script>window.location.href = 'index.php'</script>";
   }
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.vegathemes.net/gomobile/demos/splash.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:43 GMT -->
<?php include('header_links.php'); ?>
<body>
	
<div class="page page--splash" data-page="splash">
	

        <div class="splash">
		<div class="splash__content">
			<div class="splash__logo"><strong>WHEELS ON FLY</strong></div>
			<div class="splash__text">Login to your account or Signup to create a new account</div>
			<div class="splash__buttons">
				<a href="login.php" class="button button--full button--blue">Login</a>
				<a href="signup.php" class="button button--full button--green">Signup</a>
			</div>
			<div class="splash__social-login">
				<p>- Or Register with -</p>
				<div class="splash__social-icons">
					<a href="#" class="icon icon--social"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/facebook.svg" alt="" title=""/></a>
					<a href="#" class="icon icon--social"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/twitter.svg" alt="" title=""/></a>
					<a href="#" class="icon icon--social"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/instagram.svg" alt="" title=""/></a>
				</div>
			</div>
		</div>
        </div>
			  


</div>
<!-- PAGE END -->
   
<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/jquery.custom.js"></script>
</body>

<!-- Mirrored from www.vegathemes.net/gomobile/demos/splash.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:44 GMT -->
</html>