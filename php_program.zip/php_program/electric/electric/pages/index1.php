<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<?php include('header_links.php'); ?>
</head>
<body>
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--intro" data-page="intro">
	
	<!-- HEADER -->
	<?php include('header.php'); ?>
	
	
	<!-- INTRO SLIDER -->
	<div class="swiper-container slider-intro slider-intro--bottom-nav">
		<div class="swiper-wrapper">

			<div class="swiper-slide slider-intro__slide" style="background-image:url(../assets/images/slider/22.jpg);">
				<div class="slider-intro__caption caption">
				<div class="caption__content">
					<h2 class="caption__title" data-swiper-parallax="-300%" data-swiper-parallax-duration="500">CYCLING</h2>
					<p class="caption__text" data-swiper-parallax="-100%" data-swiper-parallax-duration="200">Because Cycle Don't Need Fuel To Run </p>
					<a href="login.php" class="caption__more button button--small button--blue" data-swiper-parallax="-60%" data-swiper-parallax-duration="200">Let's Start</a>
				</div>
				</div>
			</div> 
			<div class="swiper-slide slider-intro__slide" style="background-image:url(../assets/images/slider/23.jpg);">
				<div class="slider-intro__caption caption">
				<div class="caption__content">
					<h2 class="caption__title" data-swiper-parallax="-300%" data-swiper-parallax-duration="500">RIDING</h2>
					<p class="caption__text" data-swiper-parallax="-100%" data-swiper-parallax-duration="200">Bicycling Is Better For Your Body, Mind, Wallet And World</p>
					<a href="login.php" class="caption__more button button--small button--blue" data-swiper-parallax="-60%" data-swiper-parallax-duration="200">Let's Ride</a>
				</div>
				</div>
			</div> 
			<div class="swiper-slide slider-intro__slide" style="background-image:url(../assets/images/slider/24.jpg);">
				<div class="slider-intro__caption caption">
				<div class="caption__content">
					<h2 class="caption__title" data-swiper-parallax="-300%" data-swiper-parallax-duration="500">BIKING</h2>
					<p class="caption__text" data-swiper-parallax="-100%" data-swiper-parallax-duration="200">Ride A Bicycle And Keep Yourself Healthy And Fit</p>
					<a href="login.php" class="caption__more button button--small button--blue" data-swiper-parallax="-60%" data-swiper-parallax-duration="200">Register</a>
				</div>
				</div>
			</div> 
		</div>
		<div class="slider-intro__skip"><div class="text-animation"></div></div>
		<div class="swiper-pagination slider-intro__pagination"></div>
		<div class="swiper-button-prev slider-intro__prev d-none"></div>
		<div class="swiper-button-next slider-intro__next d-none"></div>	
	</div>
			  



</div>
<!-- PAGE END -->

<!-- Bottom navigation -->
<div id="bottom-toolbar" class="bottom-toolbar"></div>

<!-- Social Icons Popup -->
<div id="popup-social"></div>
 
<!-- Alert --> 
<div id="popup-alert"></div>  

    
<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/jquery.custom.js"></script>
</body>

</html>