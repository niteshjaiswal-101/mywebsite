


<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.vegathemes.net/gomobile/demos/shop.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:50 GMT -->
<head>
<?php include('header_links.php'); 
	  include('connection.php');
	   ?>
<style>
	.bg {
		background-image: url("../assets/images/slider/22.jpg");
	}
    h3{
        color: #fff;
    }
</style> 
</head>
<body>
	
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--main" data-page="shop">
	
	<header class="header header--page header--fixed">	
	<?php include('header_head.php'); ?>
	</header>
	
	<!-- PAGE CONTENT -->
	<div class="page__content page__content--with-header bg">
        <h3>SUBSCRIPTION PLANS</h3>
		<div class="toggle mb-20">
			<div class="toggle__item">
			  <input class="toggle__input" id="togg1" type="checkbox" name="toggle">
			  <label class="toggle__label" for="togg1" style="text-align:center;">Monthly Rs 99/-<span></span></label>
				  <div class="toggle__content">
					<p>This plan validate upto 28 days. Where you can book a cycle from any centre. To buy this plan <a href="razorpay/razorpay_api.php?amount=9900">Click Here</a></p>
				  </div>
			</div>
			<div class="toggle__item">
			  <input class="toggle__input" id="togg2" type="checkbox" name="toggle">
			  <label class="toggle__label" for="togg2" style="text-align:center;">Quaterly Rs 299/-<span></span></label>
				  <div class="toggle__content">
					<p>This plan validate upto 90 days. Where you can book a cycle from any centre. To buy this plan <a href="razorpay/razorpay_api.php?amount=29900">Click Here</a></p>
				  </div>
			</div>
		    <div class="toggle__item">
			  <input class="toggle__input" id="togg3" type="checkbox" name="toggle">
			  <label class="toggle__label" for="togg3" style="text-align:center;">Yearly Rs 999/-<span></span></label>
				  <div class="toggle__content">
					<p>This plan validate upto 365 days. Where you can book a cycle from any centre. To buy this plan <a href="razorpay/razorpay_api.php?amount=99900">Click Here</a></p>
				  </div>
			</div> 
		</div>
	</div>

</div>
<!-- PAGE END -->


<!-- Social Icons Popup -->
<div id="popup-social"></div>
 
<!-- Alert --> 
<div id="popup-alert"></div>  

<!-- Notifications --> 
<div id="popup-notifications"></div>  

<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/swiper-init.js"></script>
<script src="js/jquery.custom.js"></script>

</body>

<!-- Mirrored from www.vegathemes.net/gomobile/demos/shop.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:51 GMT -->
</html>