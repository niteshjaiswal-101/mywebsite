<?php
$email = $_GET['email'];
include('mail/mail.php');
// send_mail('gauri27salgaonkar@gmail.com',"test by omkar project","Hey check this cycle");
send_mail($email,"test by omkar project","Hey check this cycle");
// send_mail('hamzaindorwala3@gmail.com',"test by omkar project","Hey check this cycle");
send_mail_login($email,"Paddle Up And Traverse Welcomes","$username");
?>