<?php   
//    session_start();
//    if(!isset($_SESSION['dixit_mldcc']) && empty($_SESSION['dixit_mldcc'])){
//      echo "<script>window.location.href = 'index.php'</script>";
//    }
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.vegathemes.net/gomobile/demos/forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:54 GMT -->
<head>
<meta charset="utf-8">
<?php include('header_links.php'); ?>
</head>
<body>
	
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--main" data-page="form">
	
	<!-- HEADER -->
	<header class="header header--page header--fixed">	
		<div class="header__inner">	
        <div class="header__icon open-panel" data-panel="right" data-arrow="left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/user.svg" alt="" title="logo"/><span></span><span></span><span></span><span></span><span></span><span></span></a></div>
		<div class="header__logo header__logo--text"><a href="#"><b style="font-size:20px;">PADDLE UP & TRAVERSE</b></a></div>	
			<div class="header__icon open-panel" data-panel="right" data-arrow="left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/logout.svg" alt="" title="Login"/></div>
                </div>
	</header>
	<?php
         include('connection.php');         
         $db_con = getDB();
		//  print_r($_POST);
      ?>
	<!-- PAGE CONTENT -->
	<?php
   if (isset($_POST['submit'])) {
      $fname = $_POST['fname'];
	  $lname = $_POST['lname'];
      $address = $_POST['address'];
	  $email = $_POST['email'];
	  $pincode = $_POST['pincode'];
	  $number = $_POST['number'];
	  $dob = $_POST['dob'];
	  $age = $_POST['age'];
	  $gender = $_POST['gender'];
      $stm = $db_con->prepare("INSERT INTO `basic_details`(`fname`, `lname`, `address`,`email`, `pincode`, `number`, `dob`, `age`, `gender`, `status`) VALUES (:fname, :lname, :address, :email, :pincode, :number, :dob, :age, :gender, 'A')");
        $stm->bindParam(":fname", $fname, PDO::PARAM_STR);
        $stm->bindParam(":lname", $lname, PDO::PARAM_STR);
        $stm->bindParam(":address", $address, PDO::PARAM_STR);
		$stm->bindParam(":email", $email, PDO::PARAM_STR);
		$stm->bindParam(":pincode", $pincode, PDO::PARAM_STR);
		$stm->bindParam(":number", $number, PDO::PARAM_STR);
		$stm->bindParam(":dob", $dob, PDO::PARAM_STR);
		$stm->bindParam(":age", $age, PDO::PARAM_STR);
		$stm->bindParam(":gender", $gender, PDO::PARAM_STR);
        $stm->execute();
        // $last_id = $db_con->lastInsertId();
        // $cat_id = $last_id;
        $count = $stm->rowCount();
        // if ($count > 0) {
        //     $data["status"] = 'success';
        //     $data["reason"] = 'category_inserted';
        //     array_push($response["response"], $data);
        // } else {
        //     $data["status"] = 'failed';
        //     array_push($response["response"], $data);
        // }
   ?>
    <!-- <script>
            // Get the snackbar DIV
            var x = document.getElementById("snackbar");

            // Add the "show" class to DIV
            x.className = "show";

            // After 3 seconds, remove the show class from DIV
            setTimeout(function() {
               x.className = x.className.replace("show", "");
            }, 3000);
         </script> -->
   <?php
   }

   ?>

	<div class="page__content page__content--with-header">
		<h2 class="page__title">USER DETAILS</h2>  
		<div class="fieldset">
			<div class="form">
				<form id="Form" method="post">
					<!-- <div class="form__row">
						<input type="text" name="Text" value="" class="form__input required" placeholder="Text" />
					</div> -->
					<div class="form__row d-flex align-items-center justify-space">
						<input type="text" name="fname"  class="form__input form__input--12" id="fname" placeholder="First Name" autofocus required />
						<input type="text" name="lname" class="form__input form__input--12" id="lname" placeholder="Last Name" required/>
					</div>
					<div class="form__row d-flex align-items-center justify-space">
						<input type="text" name="address" class="form__input form__input--23" placeholder="Location (eg. vile parle)" required/>
						<input type="text" name="pincode" class="form__input form__input--13" id="pin" placeholder="Pincode" required/>
					</div>
					<div class="form__row">
						<input type="text" name="email" class="form__input required" placeholder="Email" required/>
					</div>
					<div class="form__row">
						<input type="text" name="text" id="num" class="form__input required" placeholder="Number" required/>
					</div>
					<div class="form__row">
						<input type="date" name="dob" class="form__input required" placeholder="Date Of Birth" required/>
					</div>
					<div class="form__row">
						<div class="form__select">
							<select name="age" class="required" required>
								<option value="" disabled selected>Select Age Group</option>
								<option value="below 5 years">below 5 years</option>
								<option value="6-10 years">6-10 years</option>
								<option value="11-15 years">11-15 years</option>
								<option value="16-20 years">16-20 years</option>
								<option value="Above 20 years">Above 20 years</option>
							</select>
						</div>
					</div>
					
					<h3 class="pb-20 pt-20">Select Gender<span style="color:red;">*</span></h3>
					<div class="radio-option">
						<input type="radio" name="gender" id="op4" value="male" /><label for="op4">Male</label>
					</div>
					<div class="radio-option">
						<input type="radio" name="gender" id="op5" value="female" /><label for="op5">Female</label>
					</div>
					<div class="form__row mt-40">
						<input type="submit" name="submit" class="form__submit button button--green button--full" id="submit" value="SUBMIT" />
					</div>
				</form>
			</div>
		</div>
	

		 
		
	</div>
			  



</div>
<!-- PAGE END -->


<!-- Social Icons Popup -->
<div id="popup-social"></div>
 
<!-- Alert --> 
<div id="popup-alert"></div>


<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/swiper-init-swipe.html"></script>
<script src="js/jquery.custom.js"></script>
<script>
         $(document).ready(function() {
          $("#fname").keyup(function(e) {
             var regex = /^[a-zA-Z]+$/; 
            if (regex.test(this.value) !== true)
              this.value = this.value.replace(/[^a-zA-Z]+/, '');
            });

			$("#lname").keyup(function(e) {
             var regex = /^[a-zA-Z]+$/; 
            if (regex.test(this.value) !== true)
              this.value = this.value.replace(/[^a-zA-Z]+/, '');
            });

			$("#num").keyup(function(e) {
             var regex = /^[0-9]+$/; 
            if (regex.test(this.value) !== true)
              this.value = this.value.replace(/[^0-9]+/, '');
            });

			$("#pin").keyup(function(e) {
             var regex = /^[0-9]+$/; 
            if (regex.test(this.value) !== true)
              this.value = this.value.replace(/[^0-9]+/, '');
            }); 
         });
</script>
</body>

<!-- Mirrored from www.vegathemes.net/gomobile/demos/forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:55 GMT -->
</html>