<div class="header__inner">	
			<div class="header__icon"></div>

			<div class="header__logo header__logo--text"><a href="menu.php"><b>WHEELS ON FLY</b></a></div>	
			<div class="header__icon open-panel" data-panel="right" data-arrow="left"><a href="logout.php"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/logout.svg" alt="" title="logout"/></a></div>			
			
        </div>