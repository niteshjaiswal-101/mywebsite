q<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.vegathemes.net/gomobile/demos/sliders.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:44 GMT -->
<head>
<?php include('header_links.php'); ?>
</head>
<body>
	
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--main" data-page="sliders">
	
	<header class="header header--page header--fixed">	
		<?php include('header_head.php'); ?>
	</header>
	<?php
         include('connection.php');         
         $db_con = getDB();
		//  print_r($_POST);
      ?>
	<!-- PAGE CONTENT -->
	
	<div class="page__content page__content--with-header">
		<h2 class="page__title">CYCLES</h2>
		
		<p class="welcome">

		</p>
		
		<div class="page__title-bar">
			
		</div>		
	        
		
		<div class="posts">
				<?php
					$query = "SELECT * FROM `cycle_details` WHERE STATUS='A'";
					$stmt = $db_con->prepare($query);
					$stmt->execute();
					$count = $stmt->rowCount();
					$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
				?>
				<?php
					for ($i = 0; $i < $count; $i++) {
						$sr = $i + 1;
						$id = $row[$i]['id'];
					?>
			  <div class="post">
				  <div class="post__thumb">
					  <a href="cycle_details.php?date=<?= date('his') ?>&id=<?= $id ?>"><img src="../<?= $row[$i]['image'] ?>" alt="" title=""/></a>
				  </div>
				  <div class="post__details">
					<h4 class="post__title"><a href="cycle_details.php?date=<?= date('his') ?>&id=<?= $id ?>"><?= $row[$i]['cycle_name'] ?></a></h4>
					<a href="cycle_details.php?date=<?= date('his') ?>&id=<?= $id ?>" class="post__more button button--blue button--ex-small">VIEW IT</a>
				  </div>
			  </div>
			  <a href="delete_cycle.php?id=<?= $id ?>" class="post__delete button button--red button--ex-small">DELETE</a>
			  <?php } ?>
			  
              </div>
	
	</div>
		
	
	</div>
			  



</div>
<!-- PAGE END -->


<!-- Social Icons Popup -->
<div id="popup-social"></div>
 
<!-- Alert --> 
<div id="popup-alert"></div>  

<!-- Notifications --> 
<div id="popup-notifications"></div>  

<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/swiper-init.js"></script>
<script src="js/jquery.custom.js"></script>

<script>
	$(document).ready(function() {
          $("#back").keyup(function(e) {
			"history.back()"
            });
		});
</script>

</body>

<!-- Mirrored from www.vegathemes.net/gomobile/demos/sliders.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:49 GMT -->
</html>