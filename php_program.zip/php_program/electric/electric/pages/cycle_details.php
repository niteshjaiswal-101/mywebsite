<!DOCTYPE html>
<html lang="en">

<head>
<?php include('header_links.php'); ?>
<body>
	
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--main" data-page="blog-single">

	<header class="header header--page header--fixed">	
		<div class="header__inner">	
			<div class="header__icon"></div>
			<div class="header__logo header__logo--text"><a href="#"><b>WHEELS ON FLY</b></a></div>
			<div class="header__icon header__icon--empty-space"></div>			
			
                </div>
	</header>
	<?php
         include('connection.php');         
         $db_con = getDB();
		//  print_r($_POST);
      ?>
	<!-- PAGE CONTENT -->
	<div class="page__content page__content--with-header">
		
		<div class="post-details">
        <?php          
            if(isset($_GET['id']) && $_GET['id'] !=''){
            $stm = $db_con->prepare("SELECT * FROM `cycle_details` WHERE id = :id and status= 'A'");
            $stm->bindParam(":id", $_GET['id'],PDO::PARAM_STR);                                         
            $stm->execute();                                 
            $count = $stm->rowCount();
            $row = $stm->fetchAll(PDO::FETCH_ASSOC);
            } 
                for($i=0;$i<$count;$i++){
                // $title = $row[$i]['title'] ;
                // $Description = $row[$i]['description'] ;
                // $File = $row[$i]['image'] ;
                // $Link = $row[$i]['link'] ;
                // $added_on = $row[$i]['added_on'] ;
            
                                            
        ?>
		
			<h2 class="post-details__title" style="text-align: center"><b style="font-size:40px; text-align: center"><?= $row[$i]['cycle_name'] ?></b></h2>
			
			<div class="post-details__feat-image">
			<img src="../<?= $row[$i]['image'] ?>" alt="" title=""/>
			</div>

			<div class="post-details__entry mb-20">
				
				<h2><b>Cycle Details</b></h2>
				
				<ul class="custom-listing custom-listing--checked p-20">
					<label><b>Type</b></label><li><?= $row[$i]['cycle_type'] ?></li>
					<label><b>Description</b></label><li><?= $row[$i]['description'] ?></li>
				</ul>
				
			</div>
            <?php 
                } 
            ?>
			
			</div>	
		</div>
	
	</div>
			  



</div>

<div id="popup-social"></div>
 
<!-- Alert --> 
<div id="popup-alert"></div>  


<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/swiper-init.js"></script>
<script src="js/jquery.custom.js"></script>

<script>
	$(document).ready(function() {
          $("#back").keyup(function(e) {
			"history.back()"
            });
		});
</script>

</body>

</html>