<?php 
include('send_mail.php'); 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); ?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.vegathemes.net/gomobile/demos/tables.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:55 GMT -->
<head>
<?php include('header_links.php');?>
<body>
<?php
         include('connection.php');  
		 
		// include('mail_php.php');      
         $db_con = getDB();
		//  print_r($_POST);
      ?>
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--main" data-page="tables">
	
	<!-- HEADER -->
	<header class="header header--page header--fixed">	
		<div class="header__inner">	
			<div class="header__icon header__icon--menu"><span></span><span></span><span></span><span></span><span></span><span></span></a></div>
			<div class="header__logo header__logo--text"><a href="#"><b style="font-size:20px;">PADDLE UP & TRAVERSE</b></a></div>	
			<div class="header__icon open-panel" data-panel="right" data-arrow="left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/user.svg" alt="" title=""/></div>
                </div>
	</header>
	
	<!-- PAGE CONTENT -->
	<div class="page__content page__content--with-header">
	
		<!-- <h2 class="page__title">Tables</h2> -->

	<h3>User Details</h3>	
		<?php
			$query = "SELECT * FROM `basic_details` WHERE STATUS='A'";
			$stmt = $db_con->prepare($query);
			$stmt->execute();
			$count = $stmt->rowCount();
			$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
        ?>
		
        <div class="table table--4cols">
			<table>
				<thead class="table__section--header">
					<tr>
						<td>
							Sr No.</td>
						<td>
							User Details</td>
						<!-- <td>
							Status</td> -->
					</tr>
				</thead>
				<?php
					for ($i = 0; $i < $count; $i++) {
						$sr = $i + 1;
						$id = $row[$i]['id'];
					?>
				<tbody> 
				<tr>
						<td>
							<?= $sr ?>	
						</td>
						<td>
						<?= $row[$i]['fname'].' '.$row[$i]['lname'] ?><br><br><?= $row[$i]['address'] ?><br><br><?= $row[$i]['email'] ?><br><?= $row[$i]['pincode'] ?><br><br><?= $row[$i]['number'] ?><br><br><?= $row[$i]['dob'] ?><br><br><?= $row[$i]['age'] ?><br><br><?= $row[$i]['gender'] ?>
						</td>
						<td>
						<!-- <a href="send_mail.php?email=<?= $row[$i]['email'] ?>" class="button button--green button--ex-small">Verify</a>
						</td> -->
					</tr>
				</tbody>
				<?php
					}
				?>
			</table>
				
		</div>
	</div>
			  



</div>
<!-- PAGE END -->

<!-- Social Icons Popup -->
<div id="popup-social"></div>
 
<!-- Alert --> 
<div id="popup-alert"></div>  


<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/swiper-init.js"></script>
<script src="js/jquery.custom.js"></script>

<script>
// 	function send_mail(email){
// var result =""
// document.write(result);
// }
</script>
<script>
	$(document).ready(function() {
          $("#back").keyup(function(e) {
			"history.back()"
            });
		});


</script>
</body>

<!-- Mirrored from www.vegathemes.net/gomobile/demos/tables.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:55 GMT -->
</html>