<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); 
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.vegathemes.net/gomobile/demos/forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:54 GMT -->
<head>
<?php include('header_links.php'); ?>
</head>
<body>
	
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--main" data-page="form">
	
	<!-- HEADER -->
	<header class="header header--page header--fixed">	
		<div class="header__inner">	
			<div class="header__icon header__icon--menu open-panel" data-panel="left" data-arrow="right"><span></span><span></span><span></span><span></span><span></span><span></span></a></div>
			<div class="header__logo header__logo--text"><a href="#"><b style="font-size:20px;">PADDLE UP & TRAVERSE</b></a></div>		
			<div class="header__icon open-panel" data-panel="right" data-arrow="left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/user.svg" alt="" title=""/></div>
                </div>
	</header>
	<?php
         include('connection.php');         
         $db_con = getDB();
		//  print_r($_POST);
	
    if (isset($_POST['submit'])) {
      $cycle_name = $_POST['cycle_name'];
	  $cycle_type = $_POST['cycle_type'];
      $description = $_POST['description'];
	  //$available_cycles = $_POST['available_cycles'];
	  $cycle_price = $_POST['cycle_price']; // New line to retrieve cycle price
    //   $file = $_POST['image'];

	$extension = array("jpeg", "jpg", "png", "gif", "bmp");

	$file_name = $_FILES["image"]["name"];           //abc.jpg
	$file_tmp = $_FILES["image"]["tmp_name"];        //temp files
	$ext = pathinfo($file_name, PATHINFO_EXTENSION); //jpg store honar

	if (in_array($ext, $extension)) {
		$filename = basename($file_name, $ext);     //only abc
		$newFileName = $filename . "-"  . time() . "." . $ext;
		$target_dir = "../cycle_img/";    // path from api folder
		str_replace(" ", "-", $target_dir);
		if (!file_exists($target_dir)) { //if directory does not exist
			mkdir($target_dir, 0777, true); //creating directory
		}
		str_replace(" ", "-", $newFileName);          //replace space by -
		move_uploaded_file($file_tmp = $_FILES["image"]["tmp_name"], $target_dir . $newFileName);

		$img_path = "../cycle_img/" . $newFileName;
		str_replace(" ", "-", $img_path);
		// $stm->debugDumpParams();    

		// echo "category image : " . $img_path . "\n";
	}
	else 
	{
		$data["status"] = 'failed';
		$data["reason"] = 'extension_error';
	}

    $stm = $db_con->prepare("INSERT INTO `cycle_details`(`cycle_name`, `cycle_type`, `description`, `image`, `status`, `cycle_price`) VALUES (:cycle_name, :cycle_type, :description, :image, 'A', :cycle_price)"); // Modified query to include cycle_price
    $stm->bindParam(":cycle_name", $cycle_name, PDO::PARAM_STR);
    $stm->bindParam(":cycle_type", $cycle_type, PDO::PARAM_STR);
    $stm->bindParam(":description", $description, PDO::PARAM_STR);
    $stm->bindParam(":image", $img_path, PDO::PARAM_STR);
    $stm->bindParam(":cycle_price", $cycle_price, PDO::PARAM_STR); // New line to bind cycle price
    $stm->execute();
        // $last_id = $db_con->lastInsertId();
        // $cat_id = $last_id;
        $count = $stm->rowCount();
        // if ($count > 0) {
        //     $data["status"] = 'success';
        //     $data["reason"] = 'category_inserted';
        //     array_push($response["response"], $data);
        // } else {
        //     $data["status"] = 'failed';
        //     array_push($response["response"], $data);
        // }
   ?>
   <?php
   }

   ?>
	<div class="page__content page__content--with-header">
		<h2 class="page__title">Cycle Details</h2>  
		<div class="fieldset">
			<div class="form">
				<form id="Form" method="post" enctype="multipart/form-data">
					<div class="form__row">
						<input type="text" name="cycle_name" class="form__input required" placeholder="Cycle name" />
					</div>
					<!-- <div class="form__row">
						<input type="text" name="centre_name" class="form__input required" placeholder="Cycle number" />
					</div> -->
					<!-- <div class="form__row d-flex align-items-center justify-space">
						<input type="text" name="Text" value="" class="form__input form__input--12" placeholder="Text 1/2" />
						<input type="text" name="Text" value="" class="form__input form__input--12" placeholder="Text 1/2" />
					</div> -->
					<!-- <div class="form__row d-flex align-items-center justify-space">
						<input type="text" name="address" class="form__input form__input--23" placeholder="Address" />
						<input type="text" name="pincode" class="form__input form__input--13" placeholder="Pincode" />
					</div> -->
					<div class="form__row">
						<div class="form__select">
							<select name="cycle_type" class="required">
								<option value="" disabled selected>Cycle type</option>
								<option value="Gear">Gear</option>
								<option value="Non-Gear">Non-Gear</option>
								<option value="Other">Other</option>
							</select>
						</div>
					</div>
					<!-- <div class="form__row">
						<input type="text" name="email" class="form__input email required" placeholder="Email" />
					</div>
					<div class="form__row">
						<input type="text" name="number" class="form__input required" placeholder="Number" />
					</div>-->
					<div class="form__row">
						<input type="text" name="description" class="form__input required" placeholder="description" />
					</div> 
					<!--<div class="form__row">
						<input type="number" name="available cycle" class="form__input required" placeholder="Available cycle" />
					</div> -->
                    <div class="form__row">
						<input type="file" name="image" class="form__input required" placeholder="img size(80X80)" title="80X80" />
					</div>
					<div class="form__row">
    <input type="text" name="cycle_price" class="form__input required" placeholder="Cycle Price" />
</div>

					<div class="form__row mt-40">
						<input type="submit" name="submit" class="form__submit button button--green button--full" id="submit" value="SUBMIT" />
					</div>
				</form>
			</div>
		</div>
	

		 
		
	</div>
			  



</div>
<!-- PAGE END -->


<!-- Social Icons Popup -->
<div id="popup-social"></div>
 
<!-- Alert --> 
<div id="popup-alert"></div>


<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/swiper-init-swipe.html"></script>
<script src="js/jquery.custom.js"></script>
</body>

</html>