<?php   
   session_start();
   if(!isset($_SESSION['dixit_mldcc']) && empty($_SESSION['dixit_mldcc'])){
     echo "<script>window.location.href = 'index.php'</script>";
   }
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.vegathemes.net/gomobile/demos/shop.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:50 GMT -->
<head>
<?php include('header_links.php'); ?>
</head>
<body>
	
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--main" data-page="shop">
	
	<header class="header header--page header--fixed">	
		<div class="header__inner">	
			<div class="header__icon header__icon--menu open-panel" data-panel="left" data-arrow="right"><span></span><span></span><span></span><span></span><span></span><span></span></a></div>
			<div class="header__logo header__logo--text"><a href="#"><b style="font-size:20px;">PADDLE UP & TRAVERSE</b></a></div>		
			<div class="header__icon header__icon--cart"><a href="cart.html"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/cart.svg" alt="" title=""/><span class="cart-items-nr">0</span></a></div>
                </div>
	</header>
	
	<!-- PAGE CONTENT -->
	<div class="page__content page__content--with-header">
		<h2 class="page__title">CYCLES</h2>
        <a href="book_ride.php" class="button button--green button--full mb-20">NEXT PAGE</a>
            <div class="cards cards--12">
			  <div class="card">
				  <div class="card__product"><a href="shop-details.html"><img src="../assets/images/photos/image-1.jpg" alt="" title=""/> </a><div class="card__price">$59</div></div>
				  <div class="card__details">
					  <h4 class="card__title"><a href="shop-details.html">Cycle 1</a></h4>
				  </div>
				  <div class="card__more"><a class="button button--blue button--cart addtocart" href="#">ADD TO CART</a></div>
			  </div>
			  <div class="card">
				  <div class="card__product"><a href="shop-details.html"><img src="../assets/images/photos/image-2.jpg" alt="" title=""/></a> <div class="card__price">$79</div></div>
				  <div class="card__details">
					  <h4 class="card__title"><a href="shop-details.html">Cycle 2</a></h4>
				  </div>
				  <div class="card__more"><a class="button button--blue button--cart addtocart" href="#">ADD TO CART</a></div>
			  </div>
			  <div class="card">
				  <div class="card__product"><a href="shop-details.html"><img src="../assets/images/photos/image-3.jpg" alt="" title=""/></a> <div class="card__price">$29</div></div>
				  <div class="card__details">
					  <h4 class="card__title"><a href="shop-details.html">Cycle 3</a></h4>
				  </div>
				  <div class="card__more"><a class="button button--blue button--cart addtocart" href="#">ADD TO CART</a></div>
			  </div>
			  <div class="card">
				  <div class="card__product"><a href="shop-details.html"><img src="../assets/images/photos/image-4.jpg" alt="" title=""/></a> <div class="card__price">$29</div></div>
				  <div class="card__details">
					  <h4 class="card__title"><a href="shop-details.html">Cycle 4</a></h4>
				  </div>
				  <div class="card__more"><a class="button button--blue button--cart addtocart" href="#">ADD TO CART</a></div>
			  </div>
			  <div class="card">
				  <div class="card__product"><a href="shop-details.html"><img src="../assets/images/photos/image-5.jpg" alt="" title=""/></a> <div class="card__price">$9</div></div>
				  <div class="card__details">
					  <h4 class="card__title"><a href="shop-details.html">Cycle 5</a></h4>
				  </div>
				  <div class="card__more"><a class="button button--blue button--cart addtocart" href="#">ADD TO CART</a></div>
			  </div>
			  <div class="card">
				  <div class="card__product"><a href="shop-details.html"><img src="../assets/images/photos/image-6.jpg" alt="" title=""/></a> <div class="card__price">$19</div></div>
				  <div class="card__details">
					  <h4 class="card__title"><a href="shop-details.html">Cycle 6</a></h4>
				  </div>
				  <div class="card__more"><a class="button button--blue button--cart addtocart" href="#">ADD TO CART</a></div>
			  </div>
            </div>
	      <a href="shop.html" class="button button--green button--full mb-20">NEXT PAGE</a>
	</div>

</div>
<!-- PAGE END -->


<!-- Social Icons Popup -->
<div id="popup-social"></div>
 
<!-- Alert --> 
<div id="popup-alert"></div>  

<!-- Notifications --> 
<div id="popup-notifications"></div>  

<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/swiper-init.js"></script>
<script src="js/jquery.custom.js"></script>
</body>

<!-- Mirrored from www.vegathemes.net/gomobile/demos/shop.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:51 GMT -->
</html>