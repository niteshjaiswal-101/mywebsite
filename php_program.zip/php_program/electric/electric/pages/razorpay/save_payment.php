<?php
// Retrieve payment details from the request
$data = json_decode(file_get_contents("php://input"), true);

// Extract relevant payment information
$payment_id = $data['razorpay_payment_id'];
$order_id = $data['razorpay_order_id'];
$signature = $data['razorpay_signature'];

// Insert payment details into the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ash";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind SQL statement
$stmt = $conn->prepare("INSERT INTO payments (payment_id, order_id, signature) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $payment_id, $order_id, $signature);

// Execute the statement
