<header class="header header--fixed">	
		<div class="header__inner">	
		<div class="header__icon open-panel" data-panel="right" data-arrow="left"><a href="signup.php"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/.svg" alt="" title="logo"/><span></span><span></span><span></span><span></span><span></span><span></span></a></div>
			<div class="header__logo header__logo--text"><a href="#"><b>WHEELS ON FLY</b></a></div>	
			<div class="header__icon open-panel" data-panel="right" data-arrow="left"><a href="login.php"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/user.svg" alt="" title="Login"/></a></div>
                </div>
	</header>