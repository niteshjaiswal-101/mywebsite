
<!DOCTYPE html>
<html lang="en">
<head>
<?php include('header_links.php'); ?>
</head>
<body>
    
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--main" data-page="shop">
    
    <header class="header header--page header--fixed">    
        <?php include('header_head.php'); ?>
    </header>
    <?php
         include('connection.php');        
         $db_con = getDB();
        
    if (isset($_POST['book'])) {
      $book_id = $SESSION['book_id'];
      $user_name = $_SESSION['project'];
      $select_cycle = $_POST['select_cycle'];
      $select_centre = $_POST['select_centre'];
      $date_slot = $_POST['date_slot'];
      $time_slot = $_POST['time_slot'];
      $pay_mode = $_POST['pay_mode'];
      $stm_cycle = $db_con->prepare("SELECT price FROM cycles WHERE cycle_id = :select_cycle");
    $stm_cycle->bindParam(":select_cycle", $select_cycle, PDO::PARAM_INT);
    $stm_cycle->execute();
    $cycle_price = $stm_cycle->fetchColumn();
    if ($cycle_price) {
        echo "<script>window.location.href = 'payment.php?amount={$cycle_price}'</script>";
    } else {
        echo "<div id='snackbar'>Cycle price not found</div>";
    }

      $stm = $db_con->prepare("INSERT INTO `payment`(`user_name`, `book_id`, `amount`, `payment_status`, `status`, `added_on`) VALUES (:select_cycle, :select_centre, :date_slot, :time_slot, :pay_mode,'P', 'A')");
        $stm->bindParam(":select_cycle", $select_cycle, PDO::PARAM_STR);
        $stm->bindParam(":select_centre", $select_centre, PDO::PARAM_STR);
        $stm->bindParam(":date_slot", $date_slot, PDO::PARAM_STR);
        $stm->bindParam(":time_slot", $time_slot, PDO::PARAM_STR);
        $stm->bindParam(":pay_mode", $pay_mode, PDO::PARAM_STR);
        
        $stm->execute();
        // $last_id = $db_con->lastInsertId();
        // $cat_id = $last_id;
        $count = $stm->rowCount();
        if ($count > 0) {
            echo  "<script>window.location.href = 'payment.php?amount={$select_cycle}'</script>";
             } 
             else 
           {
            echo "<div id='snackbar'>Book unsuccessful</div>";
           }
   }

   ?>
    <div class="page__content page__content--with-header">
        <h2 class="page__title">SELECT PAYMENT OPTION</h2>
            <div id="pay">
               <!-- <div class="radio-option radio-option--full">
                        <input type="radio" name="radioption" id="op1" value="1" /><label for="op1"><span>01</span>&nbsp;Cash </label>
                    </div>-->
                    <div class="radio-option radio-option--full">
                        <input type="radio" name="radioption" id="op2" value="2" /><label for="op2"><span>01</span>&nbsp;Online Payment</label>
                    </div>
                <div class="radio-option radio-option--full">
                        <input type="radio" name="radioption" id="op4" value="4" /><label for="op4"><span>02</span>&nbsp;SUBSCRIPTION</label>
                </div> 
             <!-- <div class="radio-option radio-option--full">
                        <input type="radio" name="radioption" id="op5" value="5" /><label for="op5">Centre 5 <span>05</span></label>
                </div>
                <div class="radio-option radio-option--full">
                        <input type="radio" name="radioption" id="op6" value="6" /><label for="op6">Centre 6 <span>06</span></label>
                </div>
                <div class="radio-option radio-option--full">
                        <input type="radio" name="radioption" id="op7" value="7" /><label for="op7">Centre 7 <span>07</span></label>
                </div>  -->
            </div> 
            <button id="bookButton" class="button button--green button--full mb-20">BOOK</button>

    </div>

</div>
<!-- PAGE END -->


<!-- Social Icons Popup -->
<div id="popup-social"></div>
 
<!-- Alert --> 
<div id="popup-alert"></div>  

<!-- Notifications --> 
<div id="popup-notifications"></div>  

<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/swiper-init.js"></script>
<script src="js/jquery.custom.js"></script>

<script>
    $(document).ready(function(){
        $('#bookButton').click(function(){
            var selectedOption = $("input[name='radioption']:checked").val();
            if(selectedOption){
                // Redirect to appropriate page based on selected option
                if(selectedOption == '1'){
                    window.location.href = 'cash_payment.php';
                } else if(selectedOption == '2'){
                    window.location.href = '../pages/razorpay/razorpay_api.php'; // Redirect to razorpay_api.php for online payment
                } else if(selectedOption == '4'){
                    window.location.href = '../pages/subscribe_plan.php';
                }
            } else {
                alert('Please select a payment option.');
            }
        });
    });
</script>
</body>
</html>

