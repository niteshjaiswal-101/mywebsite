<?php 
    if (isset($_POST['add_category'])) {
    $status = 'A';
    $name = $_POST['category_name'] ?? '';

    $extension = array("jpeg", "jpg", "png", "gif", "bmp");

    $file_name = $_FILES["category_image"]["name"];
    $file_tmp = $_FILES["category_image"]["tmp_name"];
    $ext = pathinfo($file_name, PATHINFO_EXTENSION);

    if (in_array($ext, $extension)) {
        $filename = basename($file_name, $ext);
        $newFileName = $filename . "-"  . time() . "." . $ext;
        $target_dir = "../category_img/";    // path from api folder
        str_replace(" ", "-", $target_dir);
        if (!file_exists($target_dir)) { //if directory does not exist
            mkdir($target_dir, 0777, true); //creating directory
        }
        str_replace(" ", "-", $newFileName);
        move_uploaded_file($file_tmp = $_FILES["category_image"]["tmp_name"], $target_dir . $newFileName);

        $img_path = "category_img/" . $newFileName;
        str_replace(" ", "-", $img_path);
        // $stm->debugDumpParams();    

        // echo "category image : " . $img_path . "\n";
    } else {
        $data["status"] = 'failed';
        $data["reason"] = 'extension_error';
    }

    $stmt = $dbConn->prepare("SELECT * FROM `vg_category` WHERE title =:name and status='A' ;");
    $stmt->bindParam(":name", $name, PDO::PARAM_STR);
    $stmt->execute();
    $count = $stmt->rowCount();
    // $stm->debugDumpParams();
    if ($count > 0) {
            $data["status"] = 'failed';
            $data["reason"] = 'title_exists';
            array_push($response["response"], $data);
    } else {

        $stm = $dbConn->prepare("INSERT INTO `vg_category`( `title`, `icon`, `status`, `added_by` ,`added_on`)
            VALUES (:name, :img_path, :status,:added_by,:added_on)");
        $stm->bindParam(":name", $name, PDO::PARAM_STR);
        $stm->bindParam(":img_path", $img_path, PDO::PARAM_STR);
        $stm->bindParam(":status", $status, PDO::PARAM_STR);
        $stm->bindParam(":added_by", $added_by, PDO::PARAM_STR);
        $stm->bindParam(":added_on", $added_on, PDO::PARAM_STR);
        $stm->execute();

        $count = $stm->rowCount();

        // $stm->debugDumpParams();
        if ($count > 0) {
            $data["added_by"] = $added_by;
            $data["status"] = 'success';
            $data["reason"] = 'category_inserted';
            array_push($response["response"], $data);
        } else {

            $data["status"] = 'failed';
            $data["reason"] = 'insert_failed';
            array_push($response["response"], $data);
        }
    }


    // array_push($response["response"], $data);
    echo json_encode($response);  // translator
}


//category details main
if (isset($_POST['category_details'])) {

    $stmt = $dbConn->prepare("SELECT * FROM `vg_category` WHERE status='A'");
    $stmt->execute();
    $count = $stmt->rowCount();
    if ($count > 0) {
        $fetch_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        for ($i = 0; $i < $count; $i++) {
            $data["id"] = $fetch_data[$i]['id'];
            $data["name"] = ucfirst($fetch_data[$i]['title']);
            $data["icon"] = $fetch_data[$i]['icon'];
            $data["added_on"] = explode(" ", $fetch_data[$i]['added_on']);
            $data["status"] = "success";
            $data["reason"] = "category_details_loaded";
            array_push($response["response"], $data);
        }
    } else {
        $data["status"] = "failed";
        $data["reason"] = "failed_to_load";
        array_push($response["response"], $data);
    }
    echo json_encode($response);
}
?>