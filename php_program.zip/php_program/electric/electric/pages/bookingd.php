
<!DOCTYPE html>
<html lang="en">
<head>
<?php include('header_links.php');?>
<body>
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--main" data-page="tables">
	
	<!-- HEADER -->
	<header class="header header--page header--fixed">	
		<div class="header__inner">	
			<div class="header__icon header__icon--menu"><span></span><span></span><span></span><span></span><span></span><span></span></a></div>
			<div class="header__logo header__logo--text"><a href="#"><b style="font-size:20px;">PADDLE UP & TRAVERSE</b></a></div>	
			<div class="header__icon open-panel" data-panel="right" data-arrow="left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/user.svg" alt="" title=""/></div>
                </div>
	</header>
	
	<!-- PAGE CONTENT -->
	<div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered bg-white">
                    <thead>
                        <tr>
                            <th>Sr.No.</th>
                            <th>cycle Name</th>
                            <th>cycle Image</th>
                            <th>center</th>
                            <th>timeslot</th>
                            <th>status</th>
                            <th>payment</th>
                        </tr>
                    </thead>
                    <tbody>
                          <tr> 
                          	<td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                               
                               </tr>
        
                    </tbody>
                </table>
            </div>
        </div>
</div>


</div>
<!-- PAGE END -->

<!-- Social Icons Popup -->
<div id="popup-social"></div>
 
<!-- Alert --> 
<div id="popup-alert"></div>  


<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/swiper-init.js"></script>
<script src="js/jquery.custom.js"></script>


</body>

</html>