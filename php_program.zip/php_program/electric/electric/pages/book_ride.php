<?php
session_start();
//    if(!isset($_SESSION['dixit_mldcc']) && empty($_SESSION['dixit_mldcc'])){
//      echo "<script>window.location.href = 'index.php'</script>";
//    }
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.vegathemes.net/gomobile/demos/shop.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:50 GMT -->

<head>
	<?php include('header_links.php'); ?>
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.2.4/magnific-popup.min.css"
		integrity="sha512-FmKMJ3/fslDb/pJXoW8mGmz/TGkTJwG5x6DpU/NgRrW5+U9U/bY9hE/E3d6MnjyzT8j8pK9h+Y8DnPg/gE58w=="
		crossorigin="anonymous" referrerpolicy="no-referrer" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.2.4/jquery.magnific-popup.min.js"
		integrity="sha512-FmKMJ3/fslDb/pJXoW8mGmz/TGkTJwG5x6DpU/NgRrW5+U9U/bY9hE/E3d6MnjyzT8j8pK9h+Y8DnPg/gE58w=="
		crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

	<style>
.cycle-image {
    display: block;
    margin: 0 auto;
    max-width: 100%;
    height: auto;
    width: auto\9; /* IE8 */
    max-height: 200px; /* Adjust the maximum height as needed */
    border-radius: 10px; /* Add border radius */
    transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out; /* Add smooth transition effect */
}

.cycle-image:hover {
    background-color: rgba(255, 255, 255, 0.5); /* Change background color to transparent white */
    box-shadow: 0 0 20px rgba(255, 255, 255, 0.3); /* Add a glass-like box shadow on hover */
    transform: scale(1.6); /* Zoom in by 50% on hover */
}


		#snackbar {
			visibility: hidden;
			min-width: 250px;
			margin-left: -145px;
			background-color: #333;
			color: #fff;
			text-align: center;
			border-radius: 2px;
			padding: 16px;
			position: fixed;
			z-index: 1;
			left: 50%;
			bottom: 30px;
			font-size: 17px;
		}

		/* .aClass {
			width: 50rem;
			height: auto;
		}

		.w-h {
			width: 2rem;
			height: 2rem;
		} */


		#snackbar.show {
			visibility: visible;
			-webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
			animation: fadein 0.5s, fadeout 0.5s 2.5s;
		}

		@-webkit-keyframes fadein {
			from {
				bottom: 0;
				opacity: 0;
			}

			to {
				bottom: 30px;
				opacity: 1;
			}
		}

		@keyframes fadein {
			from {
				bottom: 0;
				opacity: 0;
			}

			to {
				bottom: 30px;
				opacity: 1;
			}
		}

		@-webkit-keyframes fadeout {
			from {
				bottom: 30px;
				opacity: 1;
			}

			to {
				bottom: 0;
				opacity: 0;
			}
		}

		@keyframes fadeout {
			from {
				bottom: 30px;
				opacity: 1;
			}

			to {
				bottom: 0;
				opacity: 0;
			}
		}

		#snackbar1 {
			visibility: hidden;
			min-width: 250px;
			margin-left: -145px;
			background-color: #333;
			color: #fff;
			text-align: center;
			border-radius: 2px;
			padding: 16px;
			position: fixed;
			z-index: 1;
			left: 50%;
			bottom: 30px;
			font-size: 17px;
		}

		#snackbar1.show {
			visibility: visible;
			-webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
			animation: fadein 0.5s, fadeout 0.5s 2.5s;
		}

		@-webkit-keyframes fadein {
			from {
				bottom: 0;
				opacity: 0;
			}

			to {
				bottom: 30px;
				opacity: 1;
			}
		}

		@keyframes fadein {
			from {
				bottom: 0;
				opacity: 0;
			}

			to {
				bottom: 30px;
				opacity: 1;
			}
		}

		@-webkit-keyframes fadeout {
			from {
				bottom: 30px;
				opacity: 1;
			}

			to {
				bottom: 0;
				opacity: 0;
			}
		}

		@keyframes fadeout {
			from {
				bottom: 30px;
				opacity: 1;
			}

			to {
				bottom: 0;
				opacity: 0;
			}
		}
	</style>

</head>

<body>
	

	<!-- Overlay panel -->
	<div class="body-overlay"></div>
	<!-- Left panel -->
	<div id="panel-left"></div>
	<!-- Right panel -->
	<div id="panel-right"></div>

	<div class="panel-close panel-close--left"><img
			src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title="" /></div>
	<div class="panel-close panel-close--right"><img
			src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title="" /></div>

	<div class="page page--main" data-page="shop">

		<header class="header header--page header--fixed">
			<?php include('header_head.php'); ?>

		</header>
		<?php
		include('connection.php');
		$db_con = getDB();
		//  print_r($_POST);
		//  print_r($_SESSION);
		?>



		<?php
		if (isset($_POST['book'])) {
			$user_id = $_SESSION['project'];
			$select_cycle = $_POST['select_cycle'];
			$select_centre = $_POST['select_centre'];
			$date_slot = $_POST['date_slot'];
			$time_slot = $_POST['time_slot'];
			//   $pay_mode = $_POST['pay_mode'];
		
			$stm = $db_con->prepare("INSERT INTO `book_ride`(`user_id`, `select_cycle`, `select_centre`, `date_slot`, `time_slot`, `booking_status`, `status`) VALUES (:user_id, :select_cycle, :select_centre, :date_slot, :time_slot, 'P', 'A')");
			$stm->bindParam(":user_id", $user_id, PDO::PARAM_STR);
			$stm->bindParam(":select_cycle", $select_cycle, PDO::PARAM_STR);
			$stm->bindParam(":select_centre", $select_centre, PDO::PARAM_STR);
			$stm->bindParam(":date_slot", $date_slot, PDO::PARAM_STR);
			$stm->bindParam(":time_slot", $time_slot, PDO::PARAM_STR);
			// $stm->bindParam(":pay_mode", $pay_mode, PDO::PARAM_STR);
			$stm->execute();
			// $stm->debugDumpParams();
			$last_id = $db_con->lastInsertId();
			$book_id = $last_id;
			$count = $stm->rowCount();
			if ($count > 0) {

				// $_SESSION['project'] = $row[0]['id'];
				echo "<div id='snackbar1'>Successful</div>
					<script> window.location.href='payment.php';</script>";
				// print_r($_SESSION);
			} else {
				echo "<div id='snackbar'>Incorrect username or password</div>";
				?>
				<script>
					// Get the snackbar DIV
					var x = document.getElementById("snackbar");

					// Add the "show" class to DIV
					x.className = "show";

					// After 3 seconds, remove the show class from DIV
					setTimeout(function () {
						x.className = x.className.replace("show", "");
					}, 3000);
				</script>
				<script>
					// Get the snackbar DIV
					var x = document.getElementById("snackbar1");

					// Add the "show" class to DIV
					x.className = "show";

					// After 3 seconds, remove the show class from DIV
					setTimeout(function () {
						x.className = x.className.replace("show", "");
					}, 3000);


					$stm_cycle = $db_con->prepare("SELECT price FROM cycles WHERE cycle_id = :select_cycle");
    $stm_cycle->bindParam(":select_cycle", $select_cycle, PDO::PARAM_INT);
    $stm_cycle->execute();
    $cycle_price = $stm_cycle->fetchColumn();
	 if ($cycle_price) {
        echo "<script>window.location.href = 'payment.php?amount={$cycle_price}'</script>";
    } else {
        echo "<div id='snackbar'>Cycle price not found</div>";
    }
				</script>
				<?php
			}

		}

		?>
		<!-- PAGE CONTENT -->
		<div class="page__content page__content--with-header">
			<form method="post" enctype="multipart/form-data">
				<h1 class="page__title" style="text-align: center;">BOOK A CYCLE</h1>
				<h2 class="page__title">SELECT CYCLES</h2>


				<?php
// Fetch cycle details from the database
$query = "SELECT * FROM `cycle_details` WHERE STATUS='A'";
$stmt = $db_con->prepare($query);
$stmt->execute();
$count = $stmt->rowCount();
$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Loop through each cycle and display details -->
<?php
for ($i = 0; $i < $count; $i++) {
    $sr = $i + 1;
    $id = $row[$i]['id'];
    $cycleName = $row[$i]['cycle_name'];
    $cycleType = $row[$i]['cycle_type'];
    $cyclePrice = $row[$i]['cycle_price']; // Fetch cycle price from the database
    $cycleImage = $row[$i]['image']; // Fetch cycle image URL from the database
    ?>

    <div class="radio-option radio-option--full">
        <a href="<?= $cycleImage ?>" target="_blank" class="aClass">
		<img src="<?= $cycleImage ?>" alt="Cycle Image" class="cycle-image" title="Cycle Image" onclick="openImage('<?= $cycleImage ?>')">

            <span class="caption__more button button--small button--green mb-20 open-image-popup w-h">Cycle Image</span>
        </a>
        <input type="radio" name="select_cycle" value="<?= $cycleName ?>" id="<?= $sr ?>" required />
        <label for="<?= $sr ?>">
            <span><?= $sr ?></span>&nbsp;&nbsp;<?= $cycleName ?>&nbsp;&nbsp;<span>Cycle Type:</span>&nbsp;<?= $cycleType ?>
            &nbsp;&nbsp;<span>Price:</span>&nbsp;<?= $cyclePrice ?> <!-- Display cycle price -->
        </label>
    </div>

<?php } ?>

				<!-- <a href="#centre" class="button button--green button--full mb-20">NEXT</a>	 -->
				<hr>
				<br>
				<h2 class="page__title">SELECT CENTRE</h2>
				<div id="centre">
					<?php
					$query = "SELECT * FROM `centre_details` WHERE STATUS='A'";
					$stmt = $db_con->prepare($query);
					$stmt->execute();
					$count = $stmt->rowCount();
					$row = $stmt->fetchAll(PDO::FETCH_ASSOC);

					for ($j = 0; $j < $count; $j++) {
						$sr = $j + 1;
						$id = $row[$j]['id'];
						?>
						<div class="radio-option radio-option--full">
							<input type="radio" name="select_centre" value="<?= $row[$j]['centre_name'] ?>"
								id="centre_<?= $sr ?>" required /><label for="centre_<?= $sr ?>"><span>
									<?= $sr ?>
								</span>&nbsp;&nbsp;
								<?= $row[$j]['centre_name'] ?>
							</label>
						</div>
						<div>
							<p><strong>Address:</strong> <?= $row[$j]['address'] ?></p>
							<p><strong>Pincode:</strong> <?= $row[$j]['pincode'] ?></p>
							<p><strong>Email:</strong> <?= $row[$j]['email'] ?></p>
							<p><strong>Number:</strong> <?= $row[$j]['number'] ?></p>
							<p><strong>Time:</strong> <?= $row[$j]['time'] ?></p>
						</div>
					

					<?php } ?>
					<hr>
					<h2 class="page__title">SELECT DATE</h2>
					<div class="form__row">
						<input type="date" name="date_slot" class="form__input required" id="rideDate"
							placeholder="Date Of Booking" />
					</div>
					<br>
					<hr>
					<br>
					<h2 class="page__title">SELECT TIME</h2>
					<div class="form__row">
						<div class="form__select">
							<select name="time_slot" class="required">
								<option value="" disabled>Select Hour</option>
								<option value="8am - 9am">8</option>
								<option value="9am - 10am">9</option>
								<option value="10am - 11am">10</option>
							</select>
							<select name="time_slot" class="required">
								<option value="" disabled>Select Mins</option>
								<option value="8am - 9am">00</option>
								<option value="9am - 10am">30</option>
							</select>
							<select name="time_slot" class="required">
								<option value="" disabled>Select AM/PM</option>
								<option value="8am - 9am">AM</option>
								<option value="9am - 10am">PM</option>
							</select>
						</div>
						<div class="form__select">
							<select name="time_slot" class="required">
								<option value="" disabled>Select Hour</option>
								<option value="8am - 9am">8</option>
								<option value="9am - 10am">9</option>
								<option value="10am - 11am">10</option>
							</select>
							<select name="time_slot" class="required">
								<option value="" disabled>Select Mins</option>
								<option value="8am - 9am">00</option>
								<option value="9am - 10am">30</option>
							</select>
							<select name="time_slot" class="required">
								<option value="" disabled>Select AM/PM</option>
								<option value="8am - 9am">AM</option>
								<option value="9am - 10am">PM</option>
							</select>
						</div>
					</div>
				</div>
				<h2 class="page__title">Select Location from Map </h2>
				<div class="fieldset">
					<iframe
						src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30161.875891654046!2d72.84145665031372!3d19.09736640913017!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c9b42151fed3%3A0xac3b84f7db9d9318!2sVile%20Parle%2C%20Mumbai%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1709611575980!5m2!1sen!2sin"
						width="100%" height="200" frameborder="0" style="border:0"></iframe> 
					
				</div>

				<form method="post" enctype="multipart/form-data" action="payment.php">
    <!-- Your form fields here -->
    <input type="hidden" name="cycle_price" value="<?= $cyclePrice ?>" />
    <div class="form__row mt-40">
        <input type="submit" name="book" class="form__submit button button--green button--full" id="book" value="BOOK" />
    </div>
</form>

			</form>

		</div>

	</div>
	<!-- PAGE END -->


	<!-- Social Icons Popup -->
	<div id="popup-social"></div>

	<!-- Alert -->
	<div id="popup-alert"></div>

	<!-- Notifications -->
	<script>
		var currentDate = new Date();

		// Format the current date to YYYY-MM-DD
		var year = currentDate.getFullYear();
		var month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
		var day = currentDate.getDate().toString().padStart(2, '0');
		var formattedDate = year + '-' + month + '-' + day;

		// Set the minimum date for the date input field
		document.getElementById('rideDate').min = formattedDate;
	</script>
	<div id="popup-notifications"></div>
	<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
	<script src="../vendor/swiper/swiper.min.js"></script>
	<script src="js/swiper-init.js"></script>
	<!-- Add this script block at the end of your HTML body -->
<script>
    $(document).ready(function () {
        // Initialize Magnific Popup for image popups
        $('.open-image-popup').magnificPopup({
            type: 'image',
            closeOnContentClick: true,
            closeBtnInside: false,
            fixedContentPos: true,
            mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
            image: {
                verticalFit: true
            },
            zoom: {
                enabled: true,
                duration: 300 // don't foget to change the duration also in CSS
            }
        });

        // Add click event listener to cycle buttons
        $('.open-image-popup').click(function(event) {
            // Prevent default link behavior
            event.preventDefault();

            // Get the href attribute which contains the image URL
            var imageUrl = $(this).attr('href');

            // Open the image popup
            $.magnificPopup.open({
                items: {
                    src: imageUrl
                },
                type: 'image'
            });
        });
    });
</script>

<script>
        // Function to open image in popup
        function openImage(imageUrl) {
			$('.cycle-image').magnificPopup({
                type: 'image',
                closeOnContentClick: true,
                closeBtnInside: false,
                fixedContentPos: true,
                mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
                image: {
                    verticalFit: true
                },
                zoom: {
                    enabled: true,
                    duration: 300 // don't forget to change the duration also in CSS
                }
            });
        }
    </script>
</body>

</html>