<!DOCTYPE html>
<html lang="en">

<head>
<?php include('header_links.php'); ?>
<body>
	
<!-- Overlay panel -->
<div class="body-overlay"></div>
<!-- Left panel -->
<div id="panel-left"></div>
<!-- Right panel -->
<div id="panel-right"></div>

<div class="panel-close panel-close--left"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>
<div class="panel-close panel-close--right"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/black/close.svg" alt="" title=""/></div>

<div class="page page--main" data-page="blog-single">

	<header class="header header--page header--fixed">	
		<div class="header__inner">	
			<div class="header__icon"><a href="centre_slide.php"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/white/arrow-back.svg" alt="" title=""/></a></div>
			<div class="header__logo header__logo--text"><a href="#"><b style="font-size:20px;">PADDLE UP & TRAVERSE</b></a></div>	
			<div class="header__icon header__icon--empty-space"></div>			
			
                </div>
	</header>
	<?php
         include('connection.php');         
         $db_con = getDB();
		//  print_r($_POST);
      ?>
	<!-- PAGE CONTENT -->
	<div class="page__content page__content--with-header">
		
		<div class="post-details">
        <?php          
            if(isset($_GET['id']) !=''){
            $stm = $db_con->prepare("SELECT * FROM `centre_details` WHERE id = :id and status= 'A'");
            $stm->bindParam(":id", $_GET['id'],PDO::PARAM_STR);                                         
            $stm->execute();                                 
            $count = $stm->rowCount();
            $row = $stm->fetchAll(PDO::FETCH_ASSOC);
             
                for($i=1;$i<$count;$i++){
                // $title = $row[$i]['title'] ;
                // $Description = $row[$i]['description'] ;
                // $File = $row[$i]['image'] ;
                // $Link = $row[$i]['link'] ;
                // $added_on = $row[$i]['added_on'] ;
            
        ?>
		<div class="page__content page__content--with-header">

			<!-- SLIDER SIMPLE -->
			<div class="swiper-container slider-simple slider-thumb-init mb-10" data-paginationtype="bullets" data-spacebetweenitems="0" data-itemsperview="1">
				<div class="swiper-wrapper">
					<!-- <div class="swiper-slide slider-simple__slide" style="background-image:url(../assets/images/photos/image-1.jpg);">
					</div> 
					<div class="swiper-slide slider-simple__slide" style="background-image:url(../assets/images/photos/image-2.jpg);">
					</div> -->
					<div class="swiper-slide slider-simple__slide" style="background-image:url(../<?= $row[$i]['image'] ?>);">
					</div>
				</div>
				<!-- <div class="swiper-button-prev slider-simple__prev"></div>
				<div class="swiper-button-next slider-simple__next"></div>
				<div class="swiper-pagination slider-simple__pagination"></div> -->

			</div>

			<div class="d-flex justify-space align-items-center mb-20">
				<h2 class="page__title mb-0"><?= $row[$i]['centre_name'] ?></h2>
				<!-- <div class="shop-details-price">$59</div> -->
			</div>

			<p class="welcome">
				<label><b>Address</b></label><li><?php if($row[$i]['address'] != ''){echo $row[$i]['address'];} else{echo "No address available";}?>&nbsp;&nbsp;<label><b>Pincode:&nbsp;&nbsp;</b></label><?php if($row[$i]['pincode'] != ''){echo $row[$i]['pincode'];} else{echo "No pincode available";}?></li>
				<label><b>Email</b></label><li><?php if($row[$i]['email'] != ''){echo $row[$i]['email'];} else{echo "No email available";}?></li>
				<label><b>Contact Number</b></label><li><?php if($row[$i]['number'] != ''){echo $row[$i]['number'];} else{echo "No number available";}?			</p>
			<!-- <h3>Quantity</h3>
			<div class="quantity mb-20">
				<input type="button" value="-" class="quantity__button quantity__button--minus" field="quantity" />
				<input type="text" name="quantity" value="1" class="quantity__input" />
				<input type="button" value="+" class="quantity__button quantity__button--plus" field="quantity" />
			</div> -->
			<!-- <h3>Select size</h3>
					<div class="size-selectors">                
							<div class="size-selectors__input"> 
					<input id="size_s" type="radio" name="size" value="s">  
					<label for="size_s">S</label>
					</div>
				<div class="size-selectors__input"> 
					<input id="size_m" type="radio" name="size" value="m" checked="checked">
					<label for="size_m">M</label> 
				</div>	
				<div class="size-selectors__input"> 
					<input id="size_l" type="radio" name="size" value="l">     
					<label for="size_l">L</label>
				</div>	
				<div class="size-selectors__input"> 
					<input id="size_xl" type="radio" name="size" value="xl">  
					<label for="size_xl">XL</label>
				</div>	
				<div class="size-selectors__input"> 
					<input id="size_xxl" type="radio" name="size" value="xxl">
					<label for="size_xxl">XXL</label> 
				</div>	
					</div>  -->
			<!-- <h3>Select color</h3>
			<div class="color-selectors">    
				<div class="size-selectors__input"> 				
					<input id="color_gray" type="radio" name="color" value="gray" checked="checked">  
					<label for="color_gray" class="gray"></label>
				</div>
				<div class="size-selectors__input"> 				
					<input id="color_red" type="radio" name="color" value="red">  
					<label for="color_red" class="red"></label>
				</div>	
				<div class="size-selectors__input"> 
					<input id="color_orange" type="radio" name="color" value="orange">
					<label for="color_orange" class="orange"></label> 
				</div>	
				<div class="size-selectors__input"> 
					<input id="color_yellow" type="radio" name="color" value="yellow">
					<label for="color_yellow" class="yellow"></label> 
				</div>	
				<div class="size-selectors__input"> 
					<input id="color_green" type="radio" name="color" value="green">  
					<label for="color_green" class="green"></label>
				</div>	
				<div class="size-selectors__input"> 
					<input id="color_blue" type="radio" name="color" value="blue">
					<label for="color_blue" class="blue"></label> 
				</div>	
				<div class="size-selectors__input"> 
					<input id="color_black" type="radio" name="color" value="black">
					<label for="color_black" class="black"></label> 
				</div>	
			</div> 				 -->
			<!-- <a href="#" class="button button--green button--full mb-20 addtocart">ADD TO CART</a> -->

			</div>
			
            <?php 
                } 
			}                            

            ?>
			
			</div>	
		</div>
	
	</div>
			  



</div>

<div id="popup-social"></div>
 
<!-- Alert --> 
<div id="popup-alert"></div>  


<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/swiper-init.js"></script>
<script src="js/jquery.custom.js"></script>
</body>

</html>