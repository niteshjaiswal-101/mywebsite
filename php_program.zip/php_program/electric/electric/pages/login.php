<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include('header_links.php'); ?>
<style>
#snackbar {
  visibility: hidden;
  min-width: 250px;
  margin-left: -145px;
  background-color: #333;
  color: #fff;
  text-align: center;
  border-radius: 2px;
  padding: 16px;
  position: fixed;
  z-index: 1;
  left: 50%;
  bottom: 30px;
  font-size: 17px;
}

#snackbar.show {
  visibility: visible;
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

@-webkit-keyframes fadein {
  from {bottom: 0; opacity: 0;} 
  to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
  from {bottom: 0; opacity: 0;}
  to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {bottom: 30px; opacity: 1;} 
  to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
  from {bottom: 30px; opacity: 1;}
  to {bottom: 0; opacity: 0;}
}

	.bg {
		background-image: url("../assets/images/slider/22.jpg");
		/*background-image: url(../assets/images/slider/22.jpg);*/
        background-repeat: no-repeat;
        background-size: cover; 
	}
    .login__content{
        background: #9e9e9e80;
    }
</style>
</head>
<body>
<?php
   include('connection.php');
   $db_con = getDB();
   ?>
<div class="page page--login" data-page="login">

	<!-- HEADER -->
	<header class="header header--fixed">	
		<div class="header__inner">	
			<div class="header__icon"><a href="main.php"><img src="https://www.vegathemes.net/gomobile/assets/images/icons/gray/arrow-back.svg" alt="" title=""/></a></div>	
                </div>
	</header>
	<?php
   if (isset($_POST['login'])) {
      $username = $_POST['username'];
      $password = $_POST['password'];
      $hash_pass = trim(hash('sha256', $password));
	    //  echo $hash_pass ;
      $stm = $db_con->prepare("SELECT * FROM `ash` WHERE name=:username AND password=:password AND status='A'");
      $stm->bindParam(":username", $username, PDO::PARAM_STR);
      $stm->bindParam(":password", $hash_pass, PDO::PARAM_STR);
      $stm->execute();
    //   $stm->debugDumpParams();
      $row = $stm->fetchAll(PDO::FETCH_ASSOC);
      $count = $stm->rowCount();
      if ($count > 0) {

         $_SESSION['project'] = $row[0]['id'];
         echo  "<script>window.location.href = 'book_ride.php'</script>";
        // print_r($_SESSION);
      	} 
	  	else 
		{
         echo "<div id='snackbar'>Incorrect username or password</div>";
   ?>
   <script>
            // Get the snackbar DIV
            var x = document.getElementById("snackbar");

            // Add the "show" class to DIV
            x.className = "show";

            // After 3 seconds, remove the show class from DIV
            setTimeout(function() {
               x.className = x.className.replace("show", "");
            }, 3000);
         </script>
   <?php
      }
   }

   ?>
        <div class="login bg">
		<div class="login__content">	
			<h2 class="login__title" style="color: #fff;">Login to your account</h2>
				<div class="login-form">
					<form id="LoginForm" method="post">
						<div class="login-form__row">
							<label class="login-form__label" style="color: #fff;">Username</label>
							<input type="text" name="username" placeholder="username" pattern="[A-Za-z]{2,}" class="login-form__input required" />
						</div>
						<div class="login-form__row">
							<label class="login-form__label" style="color: #fff;">Password</label>
							<input type="password" name="password" placeholder="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" class="login-form__input required" />
						</div>
						<div class="login-form__row">
							<input type="submit" name="login" class="login-form__submit button button--blue button--full" id="submit" value="SIGN IN" />
						</div>
					</form>
					<!-- <div class="login-form__forgot-pass"><a href="forgot-password.html">Forgot Password?</a></div>		 -->
					<div class="login-form__bottom">
						<p style="color: #fff">Don't have an account?</p>
						<a href="signup.php" class="button button--green button--full" onclick>SIGN UP</a>
            <a href="signup_admin.php"><p style="color: #fff">Login as admin?</p>
					</div>
				</div>
		</div>
        </div>
			  


</div>
<!-- PAGE END -->

   
<script src="../vendor/jquery/jquery-3.5.1.min.js"></script>
<script src="../vendor/jquery/jquery.validate.min.js" ></script>
<script src="../vendor/swiper/swiper.min.js"></script>
<script src="js/jquery.custom.js"></script>
</body>

<!-- Mirrored from www.vegathemes.net/gomobile/demos/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Jan 2022 02:41:55 GMT -->
</html>